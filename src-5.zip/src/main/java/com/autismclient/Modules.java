package com.autismclient;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public final class Modules {
    public static final String[] CATEGORIES = {"Visuals", "Sky", "Movement", "Settings"};

    public static final Module FULLBRIGHT = new Module("Fullbright", "Visuals");
    public static final Module FOV = new Module("FOV", "Visuals", 30, 110, 70);
    public static final Module DARK_SKY = new Module("Dark sky", "Sky");
    public static final Module SKY_TONE = new Module("Sky tone", "Sky", 0, 100, 50);
    public static final Module SKY_STYLE = new Module("Sky style", "Sky", 0, 5, 2).withLabels("Void", "Midnight", "Galaxy", "Nebula", "Abyss", "Crimson");
    private static final int[][] SKY_PRESETS = {{0, 0, 0}, {4, 6, 20}, {16, 8, 40}, {30, 6, 36}, {2, 16, 22}, {28, 4, 8}};
    public static final Module ALWAYS_STARS = new Module("Always stars", "Sky");
    public static final Module SPRINT = new Module("Auto sprint", "Movement");
    public static final Module GLOW = new Module("Glow", "Settings");
    public static final Module OPACITY = new Module("Glass opacity", "Settings", 4, 40, 10);

    public static final List<Module> ALL = List.of(FULLBRIGHT, FOV, DARK_SKY, SKY_STYLE, SKY_TONE, ALWAYS_STARS, SPRINT, GLOW, OPACITY);

    private static boolean nightVisionApplied = false;

    static {
        GLOW.enabled = true;
    }

    private Modules() {}

    public static int skyColor() {
        int[] p = SKY_PRESETS[(int) SKY_STYLE.value];
        double t = SKY_TONE.value / 50.0;
        int r = Math.min(255, (int) (p[0] * t));
        int g = Math.min(255, (int) (p[1] * t));
        int b = Math.min(255, (int) (p[2] * t));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    public static void apply(Module m) {
        if (m == FOV) {
            MinecraftClient.getInstance().options.getFov().setValue((int) m.value);
        }
    }

    public static void tick(MinecraftClient client) {
        ClientPlayerEntity p = client.player;
        if (p == null) {
            return;
        }
        if (FULLBRIGHT.enabled) {
            StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 240) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 520, 0, false, false, false));
            }
            nightVisionApplied = true;
        } else if (nightVisionApplied) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            nightVisionApplied = false;
        }
        if (SPRINT.enabled && client.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision) {
            p.setSprinting(true);
        }
    }
}
