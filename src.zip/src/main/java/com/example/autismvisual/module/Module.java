package com.example.autismvisual.module;

/** A single toggle shown in a GUI panel. Hook your visual effect to isEnabled(). */
public class Module {
	private final String name;
	private final String category;
	private boolean enabled;

	public Module(String name, String category) {
		this.name = name;
		this.category = category;
	}

	public String getName() { return name; }
	public String getCategory() { return category; }
	public String key() { return category + "." + name; }
	public boolean isEnabled() { return enabled; }
	public void setEnabled(boolean enabled) { this.enabled = enabled; }
	public void toggle() { enabled = !enabled; }
}
