package com.example.autismvisual.module;

import com.example.autismvisual.config.VisualsConfig;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
	/** Panel order in the GUI. Add or rename categories freely. */
	public static final List<String> CATEGORIES = List.of("Sky", "Fog", "Lighting", "Particles", "Misc");

	private static final List<Module> MODULES = new ArrayList<>();

	private ModuleManager() {}

	public static void register(Module module) {
		module.setEnabled(VisualsConfig.isEnabled(module.key()));
		MODULES.add(module);
	}

	public static List<Module> all() {
		return Collections.unmodifiableList(MODULES);
	}

	public static List<Module> inCategory(String category) {
		List<Module> out = new ArrayList<>();
		for (Module m : MODULES) {
			if (m.getCategory().equals(category)) out.add(m);
		}
		return out;
	}

	public static void save() {
		for (Module m : MODULES) VisualsConfig.set(m.key(), m.isEnabled());
		VisualsConfig.save();
	}
}
