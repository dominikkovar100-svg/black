package com.example.autismvisual.config;

import com.example.autismvisual.AutismVisualClient;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.TreeMap;

/** Stores which modules are enabled in config/autismvisual.json */
public final class VisualsConfig {
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("autismvisual.json");
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static Map<String, Boolean> enabled = new TreeMap<>();

	private VisualsConfig() {}

	public static void load() {
		if (!Files.exists(FILE)) return;
		try (Reader r = Files.newBufferedReader(FILE)) {
			Type type = new TypeToken<Map<String, Boolean>>() {}.getType();
			Map<String, Boolean> loaded = GSON.fromJson(r, type);
			if (loaded != null) enabled = new TreeMap<>(loaded);
		} catch (IOException | RuntimeException e) {
			AutismVisualClient.LOGGER.warn("Could not read config, using defaults", e);
		}
	}

	public static void save() {
		try {
			Files.createDirectories(FILE.getParent());
			try (Writer w = Files.newBufferedWriter(FILE)) {
				GSON.toJson(enabled, w);
			}
		} catch (IOException e) {
			AutismVisualClient.LOGGER.warn("Could not save config", e);
		}
	}

	public static boolean isEnabled(String key) {
		return enabled.getOrDefault(key, false);
	}

	public static void set(String key, boolean value) {
		enabled.put(key, value);
	}
}
