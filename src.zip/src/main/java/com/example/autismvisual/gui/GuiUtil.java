package com.example.autismvisual.gui;

import net.minecraft.client.gui.DrawContext;

public final class GuiUtil {
	private GuiUtil() {}

	/** Rectangle with 1px clipped corners. Strips don't overlap, so translucent colors blend evenly. */
	public static void roundedRect(DrawContext ctx, int x, int y, int w, int h, int color) {
		ctx.fill(x + 1, y, x + w - 1, y + 1, color);
		ctx.fill(x, y + 1, x + w, y + h - 1, color);
		ctx.fill(x + 1, y + h - 1, x + w - 1, y + h, color);
	}
}
