package com.example.autismvisual.gui;

import com.example.autismvisual.module.ModuleManager;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
	private static final int GAP = 8;
	private static final int TOP = 34;

	// Kept between openings so panels remember their positions during a session
	private static List<Panel> panels;

	private final Screen parent;

	public ClickGuiScreen(Screen parent) {
		super(Text.literal("AutismVisual"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		if (panels == null) {
			panels = new ArrayList<>();
			for (String category : ModuleManager.CATEGORIES) panels.add(new Panel(category));
			layoutPanels();
		}

		// Big "Done" button: mobile players can't press Esc easily
		addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
				.dimensions(width / 2 - 55, height - 34, 110, 26)
				.build());
	}

	private void layoutPanels() {
		int perRow = Math.max(1, (width - GAP) / (Panel.WIDTH + GAP));
		int y = TOP;
		for (int start = 0; start < panels.size(); start += perRow) {
			int count = Math.min(perRow, panels.size() - start);
			int startX = (width - (count * (Panel.WIDTH + GAP) - GAP)) / 2;
			int rowH = 0;
			for (int i = 0; i < count; i++) {
				Panel p = panels.get(start + i);
				p.x = startX + i * (Panel.WIDTH + GAP);
				p.y = y;
				rowH = Math.max(rowH, p.height());
			}
			y += rowH + GAP;
		}
	}

	// Keep the world visible behind the GUI (no blur, no dark overlay)
	@Override
	protected void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);
		ctx.drawCenteredTextWithShadow(textRenderer, "AutismVisual", width / 2, 12, 0xFFFFFFFF);
		for (Panel p : panels) p.render(ctx, textRenderer, mouseX, mouseY);
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		double mx = click.x();
		double my = click.y();
		int button = click.button();

		// top-most panel first
		for (int i = panels.size() - 1; i >= 0; i--) {
			Panel p = panels.get(i);
			if (p.contains(mx, my)) {
				panels.remove(i);
				panels.add(p); // bring to front
				p.handleClick(mx, my, button);
				return true;
			}
		}
		return super.mouseClicked(click, doubled);
	}

	@Override
	public boolean mouseDragged(Click click, double offsetX, double offsetY) {
		for (Panel p : panels) {
			if (p.dragging) {
				p.dragTo(click.x(), click.y(), width, height);
				return true;
			}
		}
		return super.mouseDragged(click, offsetX, offsetY);
	}

	@Override
	public boolean mouseReleased(Click click) {
		for (Panel p : panels) p.dragging = false;
		return super.mouseReleased(click);
	}

	// Scroll wheel moves all panels (handy on small screens)
	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
		for (Panel p : panels) p.y += (int) (vertical * 12);
		return true;
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void close() {
		ModuleManager.save();
		if (client != null) client.setScreen(parent);
	}
}
