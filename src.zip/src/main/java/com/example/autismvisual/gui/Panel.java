package com.example.autismvisual.gui;

import com.example.autismvisual.module.Module;
import com.example.autismvisual.module.ModuleManager;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

/** One draggable, collapsible category column. Sizes are touch-friendly. */
public class Panel {
	public static final int WIDTH = 112;
	public static final int HEADER_H = 26;
	public static final int ROW_H = 24;
	public static final int PAD = 4;

	private static final int COL_HEADER = 0xE62A3340;
	private static final int COL_BODY = 0xCC1B222C;
	private static final int COL_ROW_HOVER = 0x33FFFFFF;
	private static final int COL_ON = 0xF02ECC71;
	private static final int COL_TEXT = 0xFFFFFFFF;
	private static final int COL_MUTED = 0xFF8A94A3;

	private final String title;
	private final List<Module> modules;

	public int x, y;
	public boolean collapsed;
	public boolean dragging;
	private int dragOffX, dragOffY;

	public Panel(String category) {
		this.title = category;
		this.modules = ModuleManager.inCategory(category);
	}

	public int height() {
		return HEADER_H + (collapsed ? 0 : bodyHeight());
	}

	private int bodyHeight() {
		return Math.max(modules.size(), 1) * ROW_H + PAD * 2;
	}

	public boolean contains(double mx, double my) {
		return mx >= x && mx < x + WIDTH && my >= y && my < y + height();
	}

	public void render(DrawContext ctx, TextRenderer tr, int mx, int my) {
		int textY = (ROW_H - tr.fontHeight) / 2;

		// header
		GuiUtil.roundedRect(ctx, x, y, WIDTH, HEADER_H, COL_HEADER);
		ctx.drawCenteredTextWithShadow(tr, title, x + WIDTH / 2, y + (HEADER_H - tr.fontHeight) / 2, COL_TEXT);
		ctx.drawTextWithShadow(tr, collapsed ? "+" : "-", x + WIDTH - 14, y + (HEADER_H - tr.fontHeight) / 2, COL_MUTED);

		if (collapsed) return;

		// body
		ctx.fill(x, y + HEADER_H, x + WIDTH, y + height(), COL_BODY);

		if (modules.isEmpty()) {
			ctx.drawCenteredTextWithShadow(tr, "Nothing here yet", x + WIDTH / 2,
					y + HEADER_H + PAD + textY, COL_MUTED);
			return;
		}

		for (int i = 0; i < modules.size(); i++) {
			Module m = modules.get(i);
			int rx = x + PAD;
			int ry = y + HEADER_H + PAD + i * ROW_H;
			int rw = WIDTH - PAD * 2;
			boolean hovered = mx >= rx && mx < rx + rw && my >= ry && my < ry + ROW_H - 2;

			if (m.isEnabled()) {
				GuiUtil.roundedRect(ctx, rx, ry, rw, ROW_H - 2, COL_ON);
			} else if (hovered) {
				GuiUtil.roundedRect(ctx, rx, ry, rw, ROW_H - 2, COL_ROW_HOVER);
			}
			ctx.drawCenteredTextWithShadow(tr, m.getName(), x + WIDTH / 2, ry + textY - 1, COL_TEXT);
		}
	}

	/** Returns true if the click was consumed. */
	public boolean handleClick(double mx, double my, int button) {
		if (!contains(mx, my)) return false;

		if (my < y + HEADER_H) {
			// collapse zone on the right side of the header
			if (button == 0 && mx >= x + WIDTH - HEADER_H) {
				collapsed = !collapsed;
			} else {
				dragging = true;
				dragOffX = (int) mx - x;
				dragOffY = (int) my - y;
			}
			return true;
		}

		if (!collapsed && button == 0 && !modules.isEmpty()) {
			int index = (int) ((my - (y + HEADER_H + PAD)) / ROW_H);
			if (index >= 0 && index < modules.size()) {
				modules.get(index).toggle();
			}
		}
		return true;
	}

	public void dragTo(double mx, double my, int screenW, int screenH) {
		x = Math.max(0, Math.min(screenW - WIDTH, (int) mx - dragOffX));
		y = Math.max(0, Math.min(screenH - HEADER_H, (int) my - dragOffY));
	}
}
