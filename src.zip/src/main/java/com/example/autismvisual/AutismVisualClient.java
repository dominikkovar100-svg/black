package com.example.autismvisual;

import com.example.autismvisual.config.VisualsConfig;
import com.example.autismvisual.gui.ClickGuiScreen;
import com.example.autismvisual.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AutismVisualClient implements ClientModInitializer {
	public static final String MOD_ID = "autismvisual";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private static KeyBinding openKey;

	@Override
	public void onInitializeClient() {
		VisualsConfig.load();

		// ---- Register your modules here (none yet, GUI shell only) ----
		// ModuleManager.register(new Module("Example", "Sky"));
		// ---------------------------------------------------------------

		// Open the GUI with Right Shift (rebindable in Controls)
		openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.autismvisual.open",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_RIGHT_SHIFT,
				KeyBinding.Category.create(Identifier.of(MOD_ID, "main"))
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openKey.wasPressed()) {
				if (client.currentScreen == null) {
					client.setScreen(new ClickGuiScreen(null));
				}
			}
		});

		LOGGER.info("AutismVisual loaded ({} modules)", ModuleManager.all().size());
	}
}
