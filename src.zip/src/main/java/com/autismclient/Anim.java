package com.autismclient;

import java.util.Map;
import java.util.WeakHashMap;

public final class Anim {
    private static final class State {
        float v = 0.0f;
        long t = System.nanoTime();
    }

    private static final Map<Object, State> STATES = new WeakHashMap<>();
    private static Object screen = null;
    private static long screenT = 0L;

    private Anim() {}

    public static float clamp01(float t) {
        return t < 0.0f ? 0.0f : (t > 1.0f ? 1.0f : t);
    }

    public static float ease(float t) {
        float u = 1.0f - clamp01(t);
        return 1.0f - u * u * u;
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float approach(float cur, float target, float speed, float dt) {
        return cur + (target - cur) * (1.0f - (float) Math.exp(-dt * speed));
    }

    public static int mix(int a, int b, float t) {
        t = clamp01(t);
        int ia = (int) lerp(a >>> 24, b >>> 24, t);
        int ir = (int) lerp((a >> 16) & 0xFF, (b >> 16) & 0xFF, t);
        int ig = (int) lerp((a >> 8) & 0xFF, (b >> 8) & 0xFF, t);
        int ib = (int) lerp(a & 0xFF, b & 0xFF, t);
        return (ia << 24) | (ir << 16) | (ig << 8) | ib;
    }

    public static float hover(Object key, boolean on) {
        if (key == null) {
            return on ? 1.0f : 0.0f;
        }
        State s = STATES.computeIfAbsent(key, k -> new State());
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - s.t) / 1.0e9f);
        s.t = now;
        s.v = approach(s.v, on ? 1.0f : 0.0f, 16.0f, dt);
        return s.v;
    }

    public static float screenFade(Object s) {
        long now = System.nanoTime();
        if (s != screen) {
            screen = s;
            screenT = now;
        }
        return ease((now - screenT) / 250000000.0f);
    }
}
