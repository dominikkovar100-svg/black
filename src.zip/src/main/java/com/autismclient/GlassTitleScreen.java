package com.autismclient;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

public class GlassTitleScreen extends Screen {
    private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Options", "Client menu", "Quit Game"};
    private final float[] hov = new float[LABELS.length];
    private long last = System.nanoTime();
    private float intro = 0.0f;

    private int bx, by0, bw, bh, gap, titleY;
    private float titleScale;

    public GlassTitleScreen() {
        super(Text.literal("AutismClient"));
    }

    @Override
    protected void init() {
        bw = Math.min(190, width - 40);
        bh = height < 260 ? 20 : 24;
        gap = 6;
        titleScale = height < 260 ? 2.0f : 3.0f;
        int total = LABELS.length * bh + (LABELS.length - 1) * gap;
        int titleH = (int) (8 * titleScale) + 16;
        int block = titleH + 18 + total;
        titleY = Math.max(6, (height - block) / 2);
        by0 = titleY + titleH + 18;
        bx = (width - bw) / 2;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void drawTitle(DrawContext g, double t) {
        String name = "AutismClient";
        int tw = textRenderer.getWidth(name);
        float s = titleScale;
        var m = g.getMatrices();
        m.pushMatrix();
        m.translate((float) (width / 2.0 - tw * s / 2.0), (float) titleY);
        m.scale(s, s);
        int ga = (int) (26 + 10 * Math.sin(t * 1.5));
        int gc = Glass.argb(ga, 255, 255, 255);
        if ((gc >>> 24) >= 8) {
            g.drawText(textRenderer, name, -1, 0, gc, false);
            g.drawText(textRenderer, name, 1, 0, gc, false);
            g.drawText(textRenderer, name, 0, -1, gc, false);
            g.drawText(textRenderer, name, 0, 1, gc, false);
        }
        Glass.text(g, textRenderer, name, 0, 0, 0xFFFFFFFF, true);
        m.popMatrix();

        int ly = titleY + (int) (8 * s) + 4;
        for (int i = 0; i < 4; i++) {
            int half = 50 - i * 12;
            g.fill(width / 2 - half, ly + i, width / 2 + half, ly + i + 1, Glass.argb(110 - i * 28, 255, 255, 255));
        }
        String sub = "Minecraft 1.21.11";
        Glass.text(g, textRenderer, sub, (width - textRenderer.getWidth(sub)) / 2, ly + 8, 0xFFB8B8C8, false);
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1.0e9f);
        last = now;
        intro += dt;
        double t = Galaxy.time();

        Glass.alpha = 1.0f;
        Galaxy.draw(g, width, height, t);
        Glass.alpha = Anim.ease(intro / 0.7f);
        drawTitle(g, t);

        var mat = g.getMatrices();
        for (int i = 0; i < LABELS.length; i++) {
            int y = by0 + i * (bh + gap);
            boolean over = inside(mx, my, bx, y, bw, bh);
            hov[i] += ((over ? 1.0f : 0.0f) - hov[i]) * (1.0f - (float) Math.exp(-dt * 14.0f));
            float k = hov[i];
            float p = Anim.ease((intro - 0.2f - i * 0.08f) / 0.45f);
            if (p <= 0.0f) {
                continue;
            }
            Glass.alpha = p;
            mat.pushMatrix();
            mat.translate(0.0f, (1.0f - p) * 18.0f);

            for (int ring = 1; ring <= 5; ring++) {
                int a = (int) (k * 42 * (1.0 - ring / 6.0));
                Glass.outline(g, bx - ring, y - ring, bw + 2 * ring, bh + 2 * ring, 9 + ring, Glass.argb(a, 255, 255, 255));
            }
            Glass.rrect(g, bx, y, bw, bh, 9, Glass.argb(135, 0, 0, 0));
            Glass.rrect(g, bx, y, bw, bh, 9, Glass.argb((int) (16 + 34 * k), 255, 255, 255));
            Glass.outline(g, bx, y, bw, bh, 9, Glass.argb((int) (105 + 125 * k), 255, 255, 255));
            g.fill(bx + 9, y + 1, bx + bw - 9, y + 2, Glass.argb((int) (60 + 70 * k), 255, 255, 255));

            String label = LABELS[i];
            int lw = textRenderer.getWidth(label);
            Glass.text(g, textRenderer, label, bx + (bw - lw) / 2, y + (bh - 8) / 2, 0xFFFFFFFF, true);
            mat.popMatrix();
        }
        Glass.alpha = 1.0f;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0) {
            for (int i = 0; i < LABELS.length; i++) {
                if (inside(click.x(), click.y(), bx, by0 + i * (bh + gap), bw, bh)) {
                    action(i);
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    private void action(int i) {
        switch (i) {
            case 0:
                client.setScreen(new SelectWorldScreen(this));
                break;
            case 1:
                client.setScreen(new MultiplayerScreen(this));
                break;
            case 2:
                client.setScreen(new OptionsScreen(this, client.options));
                break;
            case 3:
                client.setScreen(new GlassScreen());
                break;
            default:
                client.scheduleStop();
                break;
        }
    }
}
