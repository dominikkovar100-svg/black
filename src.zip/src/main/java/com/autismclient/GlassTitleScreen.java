package com.autismclient;

import java.util.Random;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

public class GlassTitleScreen extends Screen {
    private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Options", "Client menu", "Quit Game"};
    private static final int STARS = 260;
    private static final int BAND = 520;
    private static final double[][] BLOBS = {
        {0.22, 0.32, 0.20, 140, 60, 255, 46, 0.0},
        {0.78, 0.62, 0.24, 50, 90, 255, 40, 1.7},
        {0.55, 0.22, 0.17, 255, 60, 190, 34, 3.1},
        {0.14, 0.80, 0.19, 30, 200, 220, 30, 4.4},
        {0.88, 0.18, 0.15, 90, 40, 200, 40, 5.6}
    };

    private final float[] hov = new float[LABELS.length];
    private final long start = System.nanoTime();
    private long last = System.nanoTime();

    private final float[] sx = new float[STARS];
    private final float[] sy = new float[STARS];
    private final float[] sb = new float[STARS];
    private final float[] sp = new float[STARS];
    private final float[] ss = new float[STARS];
    private final int[] sz = new int[STARS];
    private final float[] bxs = new float[BAND];
    private final float[] bys = new float[BAND];
    private final float[] bas = new float[BAND];

    private int bx, by0, bw, bh, gap, titleY;
    private float titleScale;

    public GlassTitleScreen() {
        super(Text.literal("AutismClient"));
        Random r = new Random(1337L);
        for (int i = 0; i < STARS; i++) {
            sx[i] = r.nextFloat();
            sy[i] = r.nextFloat();
            sb[i] = 0.35f + r.nextFloat() * 0.65f;
            sp[i] = r.nextFloat() * 6.28f;
            ss[i] = 1.5f + r.nextFloat() * 5.0f;
            sz[i] = r.nextFloat() < 0.08f ? 2 : 1;
        }
        for (int i = 0; i < BAND; i++) {
            float u = r.nextFloat();
            float off = (float) (r.nextGaussian() * 0.07);
            bxs[i] = u;
            bys[i] = 0.95f - 0.8f * u + off;
            bas[i] = (float) Math.exp(-(off / 0.07) * (off / 0.07) * 0.5) * (0.25f + r.nextFloat() * 0.6f);
        }
    }

    @Override
    protected void init() {
        bw = Math.min(190, width - 40);
        bh = height < 260 ? 20 : 24;
        gap = 6;
        titleScale = height < 260 ? 2.0f : 3.0f;
        int total = LABELS.length * bh + (LABELS.length - 1) * gap;
        int titleH = (int) (8 * titleScale) + 16;
        int block = titleH + 18 + total;
        titleY = Math.max(6, (height - block) / 2);
        by0 = titleY + titleH + 18;
        bx = (width - bw) / 2;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void blob(DrawContext g, int cx, int cy, int r, int cr, int cg, int cb, int amax) {
        int step = 3;
        for (int x = -r; x < r; x += step) {
            double u = (x + step / 2.0) / r;
            double f = 1.0 - u * u;
            if (f <= 0) {
                continue;
            }
            int a = (int) (amax * f * f);
            int h = (int) (r * 0.75 * Math.sqrt(f));
            if (h < 1 || a < 1) {
                continue;
            }
            g.fillGradient(cx + x, cy - h, cx + x + step, cy, Glass.argb(0, cr, cg, cb), Glass.argb(a, cr, cg, cb));
            g.fillGradient(cx + x, cy, cx + x + step, cy + h, Glass.argb(a, cr, cg, cb), Glass.argb(0, cr, cg, cb));
        }
    }

    private void drawGalaxy(DrawContext g, double t) {
        g.fillGradient(0, 0, width, height, 0xFF010107, 0xFF0A0719);

        for (double[] b : BLOBS) {
            int cx = (int) (width * b[0] + Math.sin(t * 0.07 + b[7]) * width * 0.02);
            int cy = (int) (height * b[1] + Math.cos(t * 0.05 + b[7]) * height * 0.03);
            int r = (int) (width * b[2]);
            blob(g, cx, cy, r, (int) b[3], (int) b[4], (int) b[5], (int) b[6]);
        }

        for (int i = 0; i < BAND; i++) {
            int x = (int) (bxs[i] * width);
            int y = (int) (bys[i] * height);
            double tw = 0.7 + 0.3 * Math.sin(t * 0.9 + i);
            int a = (int) (150 * bas[i] * tw);
            g.fill(x, y, x + 1, y + 1, Glass.argb(a, 200, 205, 255));
        }

        for (int i = 0; i < STARS; i++) {
            double fx = (sx[i] * width + t * ss[i]) % width;
            int x = (int) fx;
            int y = (int) (sy[i] * height);
            double tw = 0.65 + 0.35 * Math.sin(t * (0.7 + ss[i] * 0.25) + sp[i]);
            int a = (int) (255 * sb[i] * tw);
            int m = i % 3;
            int cr = m == 0 ? 255 : (m == 1 ? 190 : 255);
            int cg = m == 0 ? 255 : (m == 1 ? 210 : 235);
            int cb = m == 0 ? 255 : (m == 1 ? 255 : 190);
            g.fill(x, y, x + sz[i], y + sz[i], Glass.argb(a, cr, cg, cb));
            if (sz[i] == 2) {
                int ga = a / 4;
                g.fill(x - 2, y, x + 4, y + 1, Glass.argb(ga, cr, cg, cb));
                g.fill(x, y - 2, x + 1, y + 4, Glass.argb(ga, cr, cg, cb));
            }
        }

        double p = t % 9.0;
        if (p < 1.0) {
            long cycle = (long) (t / 9.0);
            double fa = (cycle * 0.6180339) % 1.0;
            double fb = (cycle * 0.7548776) % 1.0;
            double hx = width * (0.1 + 0.5 * fa) + p * width * 0.3;
            double hy = height * (0.05 + 0.3 * fb) + p * width * 0.3 * 0.45;
            for (int k = 0; k < 16; k++) {
                int a = (int) ((1.0 - k / 16.0) * 230 * (1.0 - p * 0.5));
                int px = (int) (hx - k * 3);
                int py = (int) (hy - k * 1.35);
                g.fill(px, py, px + 1 + (k < 3 ? 1 : 0), py + 1, Glass.argb(a, 255, 255, 255));
            }
        }

        g.fillGradient(0, 0, width, height / 4, 0xAA000000, 0x00000000);
        g.fillGradient(0, height * 3 / 4, width, height, 0x00000000, 0xCC000000);
    }

    private void drawTitle(DrawContext g, double t) {
        String name = "AutismClient";
        int tw = textRenderer.getWidth(name);
        float s = titleScale;
        var m = g.getMatrices();
        m.pushMatrix();
        m.translate((float) (width / 2.0 - tw * s / 2.0), (float) titleY);
        m.scale(s, s);
        int ga = (int) (26 + 10 * Math.sin(t * 1.5));
        int gc = Glass.argb(ga, 255, 255, 255);
        g.drawText(textRenderer, name, -1, 0, gc, false);
        g.drawText(textRenderer, name, 1, 0, gc, false);
        g.drawText(textRenderer, name, 0, -1, gc, false);
        g.drawText(textRenderer, name, 0, 1, gc, false);
        g.drawText(textRenderer, name, 0, 0, 0xFFFFFFFF, true);
        m.popMatrix();

        int ly = titleY + (int) (8 * s) + 4;
        for (int i = 0; i < 4; i++) {
            int half = 50 - i * 12;
            g.fill(width / 2 - half, ly + i, width / 2 + half, ly + i + 1, Glass.argb(110 - i * 28, 255, 255, 255));
        }
        String sub = "Minecraft 1.21.11";
        g.drawText(textRenderer, sub, (width - textRenderer.getWidth(sub)) / 2, ly + 8, 0xFFB8B8C8, false);
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1.0e9f);
        last = now;
        double t = (now - start) / 1.0e9;

        drawGalaxy(g, t);
        drawTitle(g, t);

        for (int i = 0; i < LABELS.length; i++) {
            int y = by0 + i * (bh + gap);
            boolean over = inside(mx, my, bx, y, bw, bh);
            hov[i] += ((over ? 1.0f : 0.0f) - hov[i]) * (1.0f - (float) Math.exp(-dt * 14.0f));
            float k = hov[i];

            for (int ring = 1; ring <= 5; ring++) {
                int a = (int) (k * 42 * (1.0 - ring / 6.0));
                Glass.outline(g, bx - ring, y - ring, bw + 2 * ring, bh + 2 * ring, 9 + ring, Glass.argb(a, 255, 255, 255));
            }
            Glass.rrect(g, bx, y, bw, bh, 9, Glass.argb(135, 0, 0, 0));
            Glass.rrect(g, bx, y, bw, bh, 9, Glass.argb((int) (16 + 34 * k), 255, 255, 255));
            Glass.outline(g, bx, y, bw, bh, 9, Glass.argb((int) (105 + 125 * k), 255, 255, 255));
            g.fill(bx + 9, y + 1, bx + bw - 9, y + 2, Glass.argb((int) (60 + 70 * k), 255, 255, 255));

            String label = LABELS[i];
            int lw = textRenderer.getWidth(label);
            g.drawText(textRenderer, label, bx + (bw - lw) / 2, y + (bh - 8) / 2, 0xFFFFFFFF, true);
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0) {
            for (int i = 0; i < LABELS.length; i++) {
                if (inside(click.x(), click.y(), bx, by0 + i * (bh + gap), bw, bh)) {
                    action(i);
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    private void action(int i) {
        switch (i) {
            case 0:
                client.setScreen(new SelectWorldScreen(this));
                break;
            case 1:
                client.setScreen(new MultiplayerScreen(this));
                break;
            case 2:
                client.setScreen(new OptionsScreen(this, client.options));
                break;
            case 3:
                client.setScreen(new GlassScreen());
                break;
            default:
                client.scheduleStop();
                break;
        }
    }
}
