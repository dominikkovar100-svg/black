package com.autismclient;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

/** Saves and loads toggles, slider values, panel positions and HUD positions. */
public final class Config {
    /** Panel layout from disk: category -> [x, y, open]. GlassScreen reads and updates this. */
    public static JsonObject panels = new JsonObject();
    /** Discord application id. Edit it in config/autismclient.json. */
    public static String discordAppId = "";
    /** True when a saved FOV should be re-applied on the first tick. */
    public static boolean fovPending = false;

    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("autismclient.json");
    }

    private static String key(Module m) {
        return m.category + "/" + m.name;
    }

    private static JsonArray pair(int a, int b) {
        JsonArray arr = new JsonArray();
        arr.add(a);
        arr.add(b);
        return arr;
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            root.addProperty("discordAppId", discordAppId);
            root.addProperty("fovSet", Modules.fovSet);

            JsonObject mods = new JsonObject();
            for (Module m : Modules.ALL) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.enabled);
                if (m.slider) {
                    o.addProperty("value", m.value);
                }
                mods.add(key(m), o);
            }
            root.add("modules", mods);

            JsonObject hud = new JsonObject();
            hud.add("armor", pair(HudRenderer.armorX, HudRenderer.armorY));
            hud.add("keys", pair(HudRenderer.keyX, HudRenderer.keyY));
            hud.add("inventory", pair(HudRenderer.invX, HudRenderer.invY));
            root.add("hud", hud);

            GlassScreen.exportPanels(panels);
            root.add("panels", panels);

            Path f = file();
            Files.createDirectories(f.getParent());
            try (Writer w = Files.newBufferedWriter(f)) {
                new GsonBuilder().setPrettyPrinting().create().toJson(root, w);
            }
        } catch (Exception e) {
            System.err.println("[Oblivion X] could not save config: " + e);
        }
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) {
            return;
        }
        try (Reader r = Files.newBufferedReader(f)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();

            if (root.has("discordAppId")) {
                discordAppId = root.get("discordAppId").getAsString();
            }
            boolean fov = root.has("fovSet") && root.get("fovSet").getAsBoolean();

            JsonObject mods = root.has("modules") ? root.getAsJsonObject("modules") : new JsonObject();
            for (Module m : Modules.ALL) {
                JsonObject o = mods.has(key(m)) ? mods.getAsJsonObject(key(m)) : null;
                if (o == null) {
                    continue;
                }
                if (o.has("enabled")) {
                    m.enabled = o.get("enabled").getAsBoolean();
                }
                if (m.slider && o.has("value")) {
                    m.value = Math.max(m.min, Math.min(m.max, o.get("value").getAsDouble()));
                }
            }
            if (fov) {
                Modules.fovSet = true;
                fovPending = true;
            }

            if (root.has("hud")) {
                JsonObject hud = root.getAsJsonObject("hud");
                if (hud.has("armor")) {
                    HudRenderer.armorX = hud.getAsJsonArray("armor").get(0).getAsInt();
                    HudRenderer.armorY = hud.getAsJsonArray("armor").get(1).getAsInt();
                }
                if (hud.has("keys")) {
                    HudRenderer.keyX = hud.getAsJsonArray("keys").get(0).getAsInt();
                    HudRenderer.keyY = hud.getAsJsonArray("keys").get(1).getAsInt();
                }
                if (hud.has("inventory")) {
                    HudRenderer.invX = hud.getAsJsonArray("inventory").get(0).getAsInt();
                    HudRenderer.invY = hud.getAsJsonArray("inventory").get(1).getAsInt();
                }
            }

            if (root.has("panels")) {
                panels = root.getAsJsonObject("panels");
            }
        } catch (Exception e) {
            System.err.println("[Oblivion X] could not read config, using defaults: " + e);
        }
    }
}
