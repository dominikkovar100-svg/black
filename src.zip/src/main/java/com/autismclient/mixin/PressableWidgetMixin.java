package com.autismclient.mixin;

import com.autismclient.Glass;
import com.autismclient.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.PressableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PressableWidget.class)
public class PressableWidgetMixin {
    @Inject(method = "renderWidget", at = @At("HEAD"), cancellable = true, require = 0)
    private void autismclient$glass(DrawContext context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        if (!Modules.GLASS_UI.enabled) {
            return;
        }
        ClickableWidget w = (ClickableWidget) (Object) this;
        Glass.button(context, MinecraftClient.getInstance().textRenderer, w.getX(), w.getY(), w.getWidth(), w.getHeight(), w.getMessage(), w.isHovered(), w.active);
        ci.cancel();
    }
}
