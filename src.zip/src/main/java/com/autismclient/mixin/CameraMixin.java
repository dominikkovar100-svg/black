package com.autismclient.mixin;

import com.autismclient.FreeLook;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(Camera.class)
public class CameraMixin {
    private static final String SET_ROTATION = "Lnet/minecraft/client/render/Camera;setRotation(FF)V";

    @ModifyArg(method = "update", at = @At(value = "INVOKE", target = SET_ROTATION), index = 0, require = 0)
    private float autismclient$yaw(float yaw) {
        return FreeLook.active ? FreeLook.yaw : yaw;
    }

    @ModifyArg(method = "update", at = @At(value = "INVOKE", target = SET_ROTATION), index = 1, require = 0)
    private float autismclient$pitch(float pitch) {
        return FreeLook.active ? FreeLook.pitch : pitch;
    }
}
