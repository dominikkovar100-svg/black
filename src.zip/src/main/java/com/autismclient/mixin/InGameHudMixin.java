package com.autismclient.mixin;

import com.autismclient.HudRenderer;
import com.autismclient.Modules;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "render", at = @At("RETURN"), require = 0)
    private void autismclient$hud(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        HudRenderer.draw(context);
    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void autismclient$noVanillaCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (Modules.CROSSHAIR.enabled) {
            ci.cancel();
        }
    }
}
