package com.autismclient.mixin;

import com.autismclient.BlockFlag;
import com.autismclient.Modules;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemEntityRenderer.class)
public class ItemEntityRendererMixin {
    private static final String RENDER = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V";

    @Inject(method = "updateRenderState", at = @At("RETURN"), require = 0)
    private void autismclient$mark(ItemEntity entity, ItemEntityRenderState state, float tickProgress, CallbackInfo ci) {
        ((BlockFlag) (Object) state).autismclient$setBlock(entity.getStack().getItem() instanceof BlockItem);
    }

    @Inject(method = RENDER, at = @At("HEAD"), require = 0)
    private void autismclient$begin(ItemEntityRenderState state, MatrixStack matrices, OrderedRenderCommandQueue queue, CameraRenderState camera, CallbackInfo ci) {
        Modules.itemIsBlock = ((BlockFlag) (Object) state).autismclient$isBlock();
    }

    @Redirect(method = RENDER, at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/MathHelper;sin(F)F"), require = 0)
    private float autismclient$noBob(float v) {
        return Modules.ITEM_PHYSICS.enabled ? -1.0f : MathHelper.sin(v);
    }

    @Redirect(method = RENDER, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;multiply(Lorg/joml/Quaternionf;)V"), require = 0)
    private void autismclient$flat(MatrixStack stack, Quaternionf q) {
        stack.multiply(q);
        if (Modules.ITEM_PHYSICS.enabled && !Modules.itemIsBlock) {
            stack.translate(0.0, -0.23, 0.0);
            stack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0f));
        }
    }
}
