package com.autismclient.mixin;

import com.autismclient.Modules;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ItemEntityRenderer.class)
public class ItemEntityRendererMixin {
    private static final String RENDER = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V";

    @Redirect(method = RENDER, at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/MathHelper;sin(F)F"), require = 0)
    private float autismclient$noBob(float v) {
        return Modules.ITEM_PHYSICS.enabled ? 0.0f : MathHelper.sin(v);
    }

    @Redirect(method = RENDER, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;multiply(Lorg/joml/Quaternionf;)V"), require = 0)
    private void autismclient$flat(MatrixStack stack, Quaternionf q) {
        stack.multiply(q);
        if (Modules.ITEM_PHYSICS.enabled) {
            stack.translate(0.0, -0.30, 0.0);
            stack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0f));
        }
    }
}
