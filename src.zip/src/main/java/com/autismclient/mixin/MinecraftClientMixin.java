package com.autismclient.mixin;

import com.autismclient.GlassTitleScreen;
import com.autismclient.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true, require = 0)
    private Screen autismclient$menu(Screen screen) {
        if (Modules.CUSTOM_MENU.enabled && screen instanceof TitleScreen) {
            return new GlassTitleScreen();
        }
        return screen;
    }
}
