package com.autismclient.mixin;

import com.autismclient.Modules;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(World.class)
public class WeatherMixin {
    @Inject(method = "getRainGradient", at = @At("HEAD"), cancellable = true, require = 0)
    private void autismclient$noRain(float delta, CallbackInfoReturnable<Float> cir) {
        if (Modules.NO_WEATHER.enabled && ((World) (Object) this).isClient()) {
            cir.setReturnValue(0.0f);
        }
    }

    @Inject(method = "getThunderGradient", at = @At("HEAD"), cancellable = true, require = 0)
    private void autismclient$noThunder(float delta, CallbackInfoReturnable<Float> cir) {
        if (Modules.NO_WEATHER.enabled && ((World) (Object) this).isClient()) {
            cir.setReturnValue(0.0f);
        }
    }
}
