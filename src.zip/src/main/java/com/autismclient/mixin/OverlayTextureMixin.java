package com.autismclient.mixin;

import com.autismclient.Modules;
import com.autismclient.OverlayAccess;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(OverlayTexture.class)
public class OverlayTextureMixin implements OverlayAccess {
    @Shadow
    private NativeImageBackedTexture texture;

    @Inject(method = "<init>", at = @At("RETURN"), require = 0)
    private void autismclient$grab(CallbackInfo ci) {
        Modules.overlay = this;
        Modules.hitApplied = -1;
    }

    @Override
    public void autismclient$apply(int rgb) {
        NativeImage img = texture.getImage();
        if (img == null) {
            return;
        }
        int c = 0xB2000000 | (rgb & 0xFFFFFF);
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 16; x++) {
                img.setColorArgb(x, y, c);
            }
        }
        texture.upload();
    }
}
