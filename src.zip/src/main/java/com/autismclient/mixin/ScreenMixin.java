package com.autismclient.mixin;

import com.autismclient.Anim;
import com.autismclient.Galaxy;
import com.autismclient.Glass;
import com.autismclient.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public class ScreenMixin {
    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true, require = 0)
    private void autismclient$background(DrawContext context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        if (!Modules.GLASS_UI.enabled) {
            return;
        }
        int w = context.getScaledWindowWidth();
        int h = context.getScaledWindowHeight();
        if (MinecraftClient.getInstance().world == null) {
            Galaxy.draw(context, w, h, Galaxy.time());
        } else {
            Galaxy.dim(context, w, h, Anim.screenFade(this) * Glass.alpha);
        }
        ci.cancel();
    }
}
