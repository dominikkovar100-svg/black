package com.autismclient.mixin;

import com.autismclient.Modules;
import net.minecraft.entity.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemEntity.class)
public class ItemEntityMixin {
    @Inject(method = "getRotation", at = @At("HEAD"), cancellable = true, require = 0)
    private static void autismclient$noSpin(float age, float uniqueOffset, CallbackInfoReturnable<Float> cir) {
        if (Modules.ITEM_PHYSICS.enabled) {
            cir.setReturnValue(uniqueOffset);
        }
    }
}
