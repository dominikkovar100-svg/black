package com.autismclient.mixin;

import com.autismclient.Modules;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, require = 0)
    private MatrixStack autismclient$viewmodelPre(MatrixStack matrices) {
        if (Modules.VIEWMODEL.enabled) {
            matrices.push();
            matrices.translate(Modules.VM_X.value / 100.0, Modules.VM_Y.value / 100.0, Modules.VM_Z.value / 100.0);
            float s = (float) (Modules.VM_SCALE.value / 100.0);
            matrices.scale(s, s, s);
            Modules.vmStack = matrices;
        }
        return matrices;
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"), require = 0)
    private void autismclient$viewmodelPost(CallbackInfo ci) {
        if (Modules.vmStack != null) {
            Modules.vmStack.pop();
            Modules.vmStack = null;
        }
    }
}
