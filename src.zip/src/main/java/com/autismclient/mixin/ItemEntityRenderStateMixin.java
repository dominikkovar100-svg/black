package com.autismclient.mixin;

import com.autismclient.BlockFlag;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(ItemEntityRenderState.class)
public class ItemEntityRenderStateMixin implements BlockFlag {
    @Unique
    private boolean autismclient$block = false;

    @Override
    public boolean autismclient$isBlock() {
        return autismclient$block;
    }

    @Override
    public void autismclient$setBlock(boolean block) {
        autismclient$block = block;
    }
}
