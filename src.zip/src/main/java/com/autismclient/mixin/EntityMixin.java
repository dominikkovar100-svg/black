package com.autismclient.mixin;

import com.autismclient.FreeLook;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true, require = 0)
    private void autismclient$freeLook(double dx, double dy, CallbackInfo ci) {
        if (FreeLook.active && (Object) this == MinecraftClient.getInstance().player) {
            FreeLook.yaw += (float) dx * 0.15f;
            FreeLook.pitch = MathHelper.clamp(FreeLook.pitch + (float) dy * 0.15f, -90.0f, 90.0f);
            ci.cancel();
        }
    }
}
