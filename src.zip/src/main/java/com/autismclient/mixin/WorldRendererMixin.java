package com.autismclient.mixin;

import com.autismclient.Modules;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(WorldRenderer.class)
public class WorldRendererMixin {
    @ModifyVariable(method = "drawBlockOutline", at = @At("HEAD"), argsOnly = true, require = 0)
    private int autismclient$outlineColor(int color) {
        if (Modules.OUTLINE.enabled) {
            return Modules.pickColor(Modules.OUTLINE_COLOR, Modules.OUTLINE_RAINBOW);
        }
        return color;
    }
}
