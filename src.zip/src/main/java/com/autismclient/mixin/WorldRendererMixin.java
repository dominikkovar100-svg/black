package com.autismclient.mixin;

import com.autismclient.Anim;
import com.autismclient.Modules;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(WorldRenderer.class)
public class WorldRendererMixin {
    @ModifyVariable(method = "drawBlockOutline", at = @At("HEAD"), argsOnly = true, require = 0)
    private int autismclient$outlineColor(int color) {
        int base = Modules.OUTLINE.enabled ? Modules.pickColor(Modules.OUTLINE_COLOR, Modules.OUTLINE_RAINBOW) : color;
        if (Modules.BREAK_ANIM.enabled) {
            float k = Modules.breakShown();
            if (k > 0.01f) {
                float pulse = 0.5f + 0.5f * (float) Math.sin(System.nanoTime() / 1.2e8);
                int c = Anim.mix(0xFFB48CFF, 0xFFFF5FD2, k);
                return Anim.mix(c, 0xFFFFFFFF, pulse * k * 0.55f);
            }
        }
        return base;
    }
}
