package com.autismclient;

public interface OverlayAccess {
    void autismclient$apply(int rgb);
}
