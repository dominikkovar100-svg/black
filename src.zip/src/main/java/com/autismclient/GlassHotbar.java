package com.autismclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;

public final class GlassHotbar {
    private static float selX = -1.0f;
    private static long lastNano = System.nanoTime();
    private static int lastSel = -1;
    private static float pop = 0.0f;

    private GlassHotbar() {}

    public static void draw(DrawContext g) {
        MinecraftClient mc = MinecraftClient.getInstance();
        PlayerEntity p = mc.player;
        if (p == null) {
            return;
        }
        int w = g.getScaledWindowWidth();
        int h = g.getScaledWindowHeight();
        int x = w / 2 - 91;
        int y = h - 22;

        long nowN = System.nanoTime();
        float dt = Math.min(0.1f, (nowN - lastNano) / 1.0e9f);
        lastNano = nowN;
        int sel = p.getInventory().getSelectedSlot();
        float target = x + 1 + sel * 20;
        if (selX < 0.0f || Math.abs(selX - target) > 400.0f) {
            selX = target;
        }
        selX += (target - selX) * (1.0f - (float) Math.exp(-dt * 24.0f));
        if (sel != lastSel) {
            if (lastSel >= 0) {
                pop = 1.0f;
            }
            lastSel = sel;
        }
        pop = Anim.approach(pop, 0.0f, 9.0f, dt);

        panel(g, x, y, 182, 22);

        int sx = Math.round(selX);
        if (Modules.GLOW.enabled) {
            for (int ring = 1; ring <= 3; ring++) {
                Glass.outline(g, sx - ring, y + 1 - ring, 20 + 2 * ring, 20 + 2 * ring, 6 + ring, Glass.argb((int) (45 * (1.0 - ring / 4.0)), 255, 255, 255));
            }
        }
        Glass.rrect(g, sx, y + 1, 20, 20, 6, Glass.argb(60, 255, 255, 255));
        Glass.outline(g, sx, y + 1, 20, 20, 6, Glass.argb(230, 255, 255, 255));

        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isEmpty()) {
                continue;
            }
            int ix = x + 3 + i * 20;
            int iy = y + 3;
            if (i == sel && pop > 0.02f) {
                float cxm = ix + 8.0f;
                float cym = iy + 8.0f;
                float sc = 1.0f + 0.22f * pop;
                var mat = g.getMatrices();
                mat.pushMatrix();
                mat.translate(cxm, cym);
                mat.scale(sc, sc);
                mat.translate(-cxm, -cym);
                g.drawItem(s, ix, iy);
                g.drawStackOverlay(mc.textRenderer, s, ix, iy);
                mat.popMatrix();
            } else {
                g.drawItem(s, ix, iy);
                g.drawStackOverlay(mc.textRenderer, s, ix, iy);
            }
        }

        ItemStack off = p.getOffHandStack();
        if (!off.isEmpty()) {
            int ox = x - 26;
            panel(g, ox, y, 22, 22);
            g.drawItem(off, ox + 3, y + 3);
            g.drawStackOverlay(mc.textRenderer, off, ox + 3, y + 3);
        }
    }

    private static void panel(DrawContext g, int x, int y, int w, int h) {
        Glass.rrect(g, x, y, w, h, 7, Glass.argb(125, 0, 0, 0));
        Glass.rrect(g, x, y, w, h, 7, Glass.argb(18, 255, 255, 255));
        Glass.outline(g, x, y, w, h, 7, Glass.argb(110, 255, 255, 255));
        g.fill(x + 7, y + 1, x + w - 7, y + 2, Glass.argb(70, 255, 255, 255));
    }
}
