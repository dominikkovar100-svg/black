package com.autismclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

public final class FreeLook {
    public static boolean active = false;
    public static boolean returning = false;
    public static float yaw = 0.0f;
    public static float pitch = 0.0f;
    private static Perspective saved = null;
    private static long ty = 0L;
    private static long tp = 0L;

    private FreeLook() {}

    public static void tick(MinecraftClient client) {
        boolean want = false;
        if (Modules.FREE_LOOK.enabled && client.player != null && client.currentScreen == null) {
            long window = client.getWindow().getHandle();
            want = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;
        }
        if (want && !active) {
            if (!returning) {
                yaw = client.player.getYaw();
                pitch = client.player.getPitch();
            }
            returning = false;
            saved = client.options.getPerspective();
            if (saved.isFirstPerson()) {
                client.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            }
            active = true;
        } else if (!want && active) {
            active = false;
            returning = true;
            ty = 0L;
            tp = 0L;
            if (saved != null) {
                client.options.setPerspective(saved);
                saved = null;
            }
        }
    }

    private static boolean settled(float playerYaw, float playerPitch) {
        return Math.abs(MathHelper.wrapDegrees(playerYaw - yaw)) < 0.25f && Math.abs(playerPitch - pitch) < 0.25f;
    }

    public static float camYaw(float playerYaw) {
        if (active) {
            return yaw;
        }
        if (!returning) {
            return playerYaw;
        }
        long now = System.nanoTime();
        float dt = ty == 0L ? 0.016f : Math.min(0.1f, (now - ty) / 1.0e9f);
        ty = now;
        yaw += MathHelper.wrapDegrees(playerYaw - yaw) * (1.0f - (float) Math.exp(-dt * 12.0f));
        return yaw;
    }

    public static float camPitch(float playerPitch) {
        if (active) {
            return pitch;
        }
        if (!returning) {
            return playerPitch;
        }
        long now = System.nanoTime();
        float dt = tp == 0L ? 0.016f : Math.min(0.1f, (now - tp) / 1.0e9f);
        tp = now;
        pitch += (playerPitch - pitch) * (1.0f - (float) Math.exp(-dt * 12.0f));
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && settled(mc.player.getYaw(), mc.player.getPitch())) {
            returning = false;
            ty = 0L;
            tp = 0L;
        }
        return pitch;
    }
}
