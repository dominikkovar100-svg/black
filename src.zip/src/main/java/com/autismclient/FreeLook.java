package com.autismclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import org.lwjgl.glfw.GLFW;

public final class FreeLook {
    public static boolean active = false;
    public static float yaw = 0.0f;
    public static float pitch = 0.0f;
    private static Perspective saved = null;

    private FreeLook() {}

    public static void tick(MinecraftClient client) {
        boolean want = false;
        if (Modules.FREE_LOOK.enabled && client.player != null && client.currentScreen == null) {
            long window = client.getWindow().getHandle();
            want = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;
        }
        if (want && !active) {
            yaw = client.player.getYaw();
            pitch = client.player.getPitch();
            saved = client.options.getPerspective();
            if (saved.isFirstPerson()) {
                client.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            }
            active = true;
        } else if (!want && active) {
            active = false;
            if (saved != null) {
                client.options.setPerspective(saved);
                saved = null;
            }
        }
    }
}
