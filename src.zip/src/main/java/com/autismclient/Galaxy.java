package com.autismclient;

import java.util.Random;
import net.minecraft.client.gui.DrawContext;

public final class Galaxy {
    private static final int STARS = 260;
    private static final int BAND = 520;
    private static final double[][] BLOBS = {
        {0.22, 0.32, 0.20, 140, 60, 255, 46, 0.0},
        {0.78, 0.62, 0.24, 50, 90, 255, 40, 1.7},
        {0.55, 0.22, 0.17, 255, 60, 190, 34, 3.1},
        {0.14, 0.80, 0.19, 30, 200, 220, 30, 4.4},
        {0.88, 0.18, 0.15, 90, 40, 200, 40, 5.6}
    };
    private static final long START = System.nanoTime();

    private static final float[] sx = new float[STARS];
    private static final float[] sy = new float[STARS];
    private static final float[] sb = new float[STARS];
    private static final float[] sp = new float[STARS];
    private static final float[] ss = new float[STARS];
    private static final int[] sz = new int[STARS];
    private static final float[] bxs = new float[BAND];
    private static final float[] bys = new float[BAND];
    private static final float[] bas = new float[BAND];

    static {
        Random r = new Random(1337L);
        for (int i = 0; i < STARS; i++) {
            sx[i] = r.nextFloat();
            sy[i] = r.nextFloat();
            sb[i] = 0.35f + r.nextFloat() * 0.65f;
            sp[i] = r.nextFloat() * 6.28f;
            ss[i] = 1.5f + r.nextFloat() * 5.0f;
            sz[i] = r.nextFloat() < 0.08f ? 2 : 1;
        }
        for (int i = 0; i < BAND; i++) {
            float u = r.nextFloat();
            float off = (float) (r.nextGaussian() * 0.07);
            bxs[i] = u;
            bys[i] = 0.95f - 0.8f * u + off;
            bas[i] = (float) Math.exp(-(off / 0.07) * (off / 0.07) * 0.5) * (0.25f + r.nextFloat() * 0.6f);
        }
    }

    private Galaxy() {}

    public static double time() {
        return (System.nanoTime() - START) / 1.0e9;
    }

    public static void dim(DrawContext g, int width, int height) {
        g.fillGradient(0, 0, width, height, 0xC4010108, 0xC40A0719);
    }

    private static void blob(DrawContext g, int cx, int cy, int r, int cr, int cg, int cb, int amax) {
        int step = 3;
        for (int x = -r; x < r; x += step) {
            double u = (x + step / 2.0) / r;
            double f = 1.0 - u * u;
            if (f <= 0) {
                continue;
            }
            int a = (int) (amax * f * f);
            int h = (int) (r * 0.75 * Math.sqrt(f));
            if (h < 1 || a < 1) {
                continue;
            }
            g.fillGradient(cx + x, cy - h, cx + x + step, cy, Glass.argb(0, cr, cg, cb), Glass.argb(a, cr, cg, cb));
            g.fillGradient(cx + x, cy, cx + x + step, cy + h, Glass.argb(a, cr, cg, cb), Glass.argb(0, cr, cg, cb));
        }
    }

    public static void draw(DrawContext g, int width, int height, double t) {
        g.fillGradient(0, 0, width, height, 0xFF010107, 0xFF0A0719);

        for (double[] b : BLOBS) {
            int cx = (int) (width * b[0] + Math.sin(t * 0.07 + b[7]) * width * 0.02);
            int cy = (int) (height * b[1] + Math.cos(t * 0.05 + b[7]) * height * 0.03);
            int r = (int) (width * b[2]);
            blob(g, cx, cy, r, (int) b[3], (int) b[4], (int) b[5], (int) b[6]);
        }

        for (int i = 0; i < BAND; i++) {
            int x = (int) (bxs[i] * width);
            int y = (int) (bys[i] * height);
            double tw = 0.7 + 0.3 * Math.sin(t * 0.9 + i);
            int a = (int) (150 * bas[i] * tw);
            g.fill(x, y, x + 1, y + 1, Glass.argb(a, 200, 205, 255));
        }

        for (int i = 0; i < STARS; i++) {
            double fx = (sx[i] * width + t * ss[i]) % width;
            int x = (int) fx;
            int y = (int) (sy[i] * height);
            double tw = 0.65 + 0.35 * Math.sin(t * (0.7 + ss[i] * 0.25) + sp[i]);
            int a = (int) (255 * sb[i] * tw);
            int m = i % 3;
            int cr = m == 0 ? 255 : (m == 1 ? 190 : 255);
            int cg = m == 0 ? 255 : (m == 1 ? 210 : 235);
            int cb = m == 0 ? 255 : (m == 1 ? 255 : 190);
            g.fill(x, y, x + sz[i], y + sz[i], Glass.argb(a, cr, cg, cb));
            if (sz[i] == 2) {
                int ga = a / 4;
                g.fill(x - 2, y, x + 4, y + 1, Glass.argb(ga, cr, cg, cb));
                g.fill(x, y - 2, x + 1, y + 4, Glass.argb(ga, cr, cg, cb));
            }
        }

        double p = t % 9.0;
        if (p < 1.0) {
            long cycle = (long) (t / 9.0);
            double fa = (cycle * 0.6180339) % 1.0;
            double fb = (cycle * 0.7548776) % 1.0;
            double hx = width * (0.1 + 0.5 * fa) + p * width * 0.3;
            double hy = height * (0.05 + 0.3 * fb) + p * width * 0.3 * 0.45;
            for (int k = 0; k < 16; k++) {
                int a = (int) ((1.0 - k / 16.0) * 230 * (1.0 - p * 0.5));
                int px = (int) (hx - k * 3);
                int py = (int) (hy - k * 1.35);
                g.fill(px, py, px + 1 + (k < 3 ? 1 : 0), py + 1, Glass.argb(a, 255, 255, 255));
            }
        }

        g.fillGradient(0, 0, width, height / 4, 0xAA000000, 0x00000000);
        g.fillGradient(0, height * 3 / 4, width, height, 0x00000000, 0xCC000000);
    }
}
