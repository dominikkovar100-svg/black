package com.autismclient;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public final class Glass {
    public static float alpha = 1.0f;

    private Glass() {}

    public static int argb(int a, int r, int g, int b) {
        a = Math.max(0, Math.min(255, (int) (a * alpha)));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static int fa(int c) {
        int a = Math.max(0, Math.min(255, (int) ((c >>> 24) * alpha)));
        return (a << 24) | (c & 0xFFFFFF);
    }

    public static void text(DrawContext g, TextRenderer tr, String s, int x, int y, int color, boolean shadow) {
        int c = fa(color);
        if ((c >>> 24) < 8) {
            return;
        }
        g.drawText(tr, s, x, y, c, shadow);
    }

    public static void text(DrawContext g, TextRenderer tr, Text s, int x, int y, int color, boolean shadow) {
        int c = fa(color);
        if ((c >>> 24) < 8) {
            return;
        }
        g.drawText(tr, s, x, y, c, shadow);
    }

    private static int ins(int i, int r) {
        double d = r - i - 0.5;
        return r - (int) Math.round(Math.sqrt(Math.max(0.0, r * r - d * d)));
    }

    public static void rrect(DrawContext g, int x, int y, int w, int h, int r, int c) {
        int rr = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        g.fill(x, y + rr, x + w, y + h - rr, c);
        for (int i = 0; i < rr; i++) {
            int in = ins(i, rr);
            g.fill(x + in, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, c);
        }
    }

    public static void outline(DrawContext g, int x, int y, int w, int h, int r, int c) {
        int rr = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        g.fill(x + rr, y, x + w - rr, y + 1, c);
        g.fill(x + rr, y + h - 1, x + w - rr, y + h, c);
        g.fill(x, y + rr, x + 1, y + h - rr, c);
        g.fill(x + w - 1, y + rr, x + w, y + h - rr, c);
        for (int i = 0; i < rr; i++) {
            int in = ins(i, rr);
            int span = (i == 0) ? rr : Math.max(in + 1, ins(i - 1, rr));
            g.fill(x + in, y + i, x + span, y + i + 1, c);
            g.fill(x + w - span, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - 1 - i, x + span, y + h - i, c);
            g.fill(x + w - span, y + h - 1 - i, x + w - in, y + h - i, c);
        }
    }

    public static void button(DrawContext g, TextRenderer tr, int x, int y, int w, int h, Text label, boolean hover, boolean active) {
        button(g, tr, x, y, w, h, label, hover, active, null);
    }

    public static void button(DrawContext g, TextRenderer tr, int x, int y, int w, int h, Text label, boolean hover, boolean active, Object key) {
        float k = Anim.hover(key, hover && active);
        int r = Math.min(9, h / 2);
        for (int ring = 1; ring <= 4; ring++) {
            int a = (int) (k * 40 * (1.0 - ring / 5.0));
            outline(g, x - ring, y - ring, w + 2 * ring, h + 2 * ring, r + ring, argb(a, 255, 255, 255));
        }
        rrect(g, x, y, w, h, r, argb(active ? 135 : 90, 0, 0, 0));
        rrect(g, x, y, w, h, r, argb((int) (16 + 34 * k), 255, 255, 255));
        outline(g, x, y, w, h, r, argb(active ? (int) (105 + 125 * k) : 55, 255, 255, 255));
        g.fill(x + r, y + 1, x + w - r, y + 2, argb(active ? (int) (60 + 70 * k) : 30, 255, 255, 255));
        int lw = tr.getWidth(label);
        text(g, tr, label, x + (w - lw) / 2, y + (h - 8) / 2, active ? 0xFFFFFFFF : 0xFF8A8A96, true);
    }
}
