package com.autismclient;

import net.minecraft.client.gui.DrawContext;

public final class Glass {
    private Glass() {}

    public static int argb(int a, int r, int g, int b) {
        a = Math.max(0, Math.min(255, a));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int ins(int i, int r) {
        double d = r - i - 0.5;
        return r - (int) Math.round(Math.sqrt(Math.max(0.0, r * r - d * d)));
    }

    public static void rrect(DrawContext g, int x, int y, int w, int h, int r, int c) {
        int rr = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        g.fill(x, y + rr, x + w, y + h - rr, c);
        for (int i = 0; i < rr; i++) {
            int in = ins(i, rr);
            g.fill(x + in, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, c);
        }
    }

    public static void outline(DrawContext g, int x, int y, int w, int h, int r, int c) {
        int rr = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        g.fill(x + rr, y, x + w - rr, y + 1, c);
        g.fill(x + rr, y + h - 1, x + w - rr, y + h, c);
        g.fill(x, y + rr, x + 1, y + h - rr, c);
        g.fill(x + w - 1, y + rr, x + w, y + h - rr, c);
        for (int i = 0; i < rr; i++) {
            int in = ins(i, rr);
            int span = (i == 0) ? rr : Math.max(in + 1, ins(i - 1, rr));
            g.fill(x + in, y + i, x + span, y + i + 1, c);
            g.fill(x + w - span, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - 1 - i, x + span, y + h - i, c);
            g.fill(x + w - span, y + h - 1 - i, x + w - in, y + h - i, c);
        }
    }
}
