package com.autismclient;

public class Module {
    public final String name;
    public final String category;
    public final boolean slider;
    public final double min;
    public final double max;
    public boolean enabled;
    public double value;
    public String[] labels;
    public float anim = -1.0f;
    public float shown = -1.0f;

    public Module(String name, String category) {
        this(name, category, false, 0, 0, 0);
    }

    public Module(String name, String category, double min, double max, double value) {
        this(name, category, true, min, max, value);
    }

    private Module(String name, String category, boolean slider, double min, double max, double value) {
        this.name = name;
        this.category = category;
        this.slider = slider;
        this.min = min;
        this.max = max;
        this.value = value;
    }

    public Module withLabels(String... l) {
        this.labels = l;
        return this;
    }

    public double ratio() {
        return (value - min) / (max - min);
    }

    public void setRatio(double r) {
        r = Math.max(0.0, Math.min(1.0, r));
        value = Math.round(min + (max - min) * r);
    }
}
