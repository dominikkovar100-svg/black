package com.autismclient;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public final class Modules {
    public static final String[] CATEGORIES = {"Visuals", "Movement", "Settings"};

    public static final Module FULLBRIGHT = new Module("Fullbright", "Visuals");
    public static final Module FOV = new Module("FOV", "Visuals", 30, 110, 70);
    public static final Module SPRINT = new Module("Auto sprint", "Movement");
    public static final Module GLOW = new Module("Glow", "Settings");
    public static final Module OPACITY = new Module("Glass opacity", "Settings", 4, 40, 10);

    public static final List<Module> ALL = List.of(FULLBRIGHT, FOV, SPRINT, GLOW, OPACITY);

    private static boolean nightVisionApplied = false;

    static {
        GLOW.enabled = true;
    }

    private Modules() {}

    public static void apply(Module m) {
        if (m == FOV) {
            MinecraftClient.getInstance().options.getFov().setValue((int) m.value);
        }
    }

    public static void tick(MinecraftClient client) {
        ClientPlayerEntity p = client.player;
        if (p == null) {
            return;
        }
        if (FULLBRIGHT.enabled) {
            StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 240) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 520, 0, false, false, false));
            }
            nightVisionApplied = true;
        } else if (nightVisionApplied) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            nightVisionApplied = false;
        }
        if (SPRINT.enabled && client.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision) {
            p.setSprinting(true);
        }
    }
}
