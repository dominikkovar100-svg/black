package com.autismclient;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public final class Modules {
    public static final String[] CATEGORIES = {"Visuals", "Sky", "HUD", "Crosshair", "Viewmodel", "Entity", "Settings"};

    public static final Module FULLBRIGHT = new Module("Fullbright", "Visuals");
    public static final Module FOV = new Module("FOV", "Visuals", 30, 110, 70);
    public static final Module NO_WEATHER = new Module("No weather", "Visuals");
    public static final Module OUTLINE = new Module("Block outline color", "Visuals");
    public static final Module OUTLINE_COLOR = new Module("Outline color", "Visuals", 0, 9, 1).withLabels(COLOR_NAMES());
    public static final Module OUTLINE_RAINBOW = new Module("Outline rainbow", "Visuals");
    public static final Module DARK_SKY = new Module("Dark sky", "Sky");
    public static final Module SKY_TONE = new Module("Sky tone", "Sky", 0, 100, 50);
    public static final Module SKY_STYLE = new Module("Sky style", "Sky", 0, 5, 2).withLabels("Void", "Midnight", "Galaxy", "Nebula", "Abyss", "Crimson");
    private static final int[][] SKY_PRESETS = {{0, 0, 0}, {4, 6, 20}, {16, 8, 40}, {30, 6, 36}, {2, 16, 22}, {28, 4, 8}};
    public static final Module ALWAYS_STARS = new Module("Always stars", "Sky");
    public static final Module ARMOR_HUD = new Module("Armor HUD", "HUD");
    public static final Module ARMOR_TEXT = new Module("Durability text", "HUD");
    public static final Module KEYSTROKES = new Module("Keystrokes", "HUD");
    public static final Module KEYS_CPS = new Module("Show CPS", "HUD");
    public static final Module KEYS_RAINBOW = new Module("Keys rainbow", "HUD");
    public static final Module CROSSHAIR = new Module("Custom crosshair", "Crosshair");
    public static final Module CH_STYLE = new Module("Style", "Crosshair", 0, 4, 1).withLabels("Dot", "Circle", "X", "Plus", "Square");
    public static final Module CH_SIZE = new Module("Size", "Crosshair", 1, 12, 4);
    public static final Module CH_COLOR = new Module("Color", "Crosshair", 0, 9, 0).withLabels(COLOR_NAMES());
    public static final Module CH_RAINBOW = new Module("Rainbow", "Crosshair");
    public static final Module VIEWMODEL = new Module("Viewmodel", "Viewmodel");
    public static final Module VM_X = new Module("Offset X", "Viewmodel", -50, 50, 0);
    public static final Module VM_Y = new Module("Offset Y", "Viewmodel", -50, 50, 0);
    public static final Module VM_Z = new Module("Offset Z", "Viewmodel", -50, 50, 0);
    public static final Module VM_SCALE = new Module("Scale", "Viewmodel", 20, 150, 100);
    public static final Module ITEM_PHYSICS = new Module("Item physics", "Entity");
    public static final Module HIT_COLOR = new Module("Custom hit color", "Entity");
    public static final Module HIT_SEL = new Module("Hit color", "Entity", 0, 9, 5).withLabels(COLOR_NAMES());
    public static final Module HIT_RAINBOW = new Module("Hit rainbow", "Entity");
    public static final Module GLASS_UI = new Module("Glass UI everywhere", "Settings");
    public static final Module SPRINT = new Module("Auto sprint", "Settings");
    public static final Module CUSTOM_MENU = new Module("Custom menu", "Settings");
    public static final Module GLOW = new Module("Glow", "Settings");
    public static final Module OPACITY = new Module("Glass opacity", "Settings", 4, 40, 10);

    public static final List<Module> ALL = List.of(FULLBRIGHT, FOV, NO_WEATHER, OUTLINE, OUTLINE_COLOR, OUTLINE_RAINBOW, DARK_SKY, SKY_STYLE, SKY_TONE, ALWAYS_STARS, ARMOR_HUD, ARMOR_TEXT, KEYSTROKES, KEYS_CPS, KEYS_RAINBOW, CROSSHAIR, CH_STYLE, CH_SIZE, CH_COLOR, CH_RAINBOW, VIEWMODEL, VM_X, VM_Y, VM_Z, VM_SCALE, ITEM_PHYSICS, HIT_COLOR, HIT_SEL, HIT_RAINBOW, SPRINT, GLOW, OPACITY, CUSTOM_MENU, GLASS_UI);

    private static boolean nightVisionApplied = false;

    static {
        GLOW.enabled = true;
        CUSTOM_MENU.enabled = true;
        GLASS_UI.enabled = true;
    }

    public static net.minecraft.client.util.math.MatrixStack vmStack = null;
    public static OverlayAccess overlay = null;
    public static int hitApplied = -1;

    private static void updateHit() {
        if (overlay == null) {
            return;
        }
        int want = HIT_COLOR.enabled ? (HIT_RAINBOW.enabled ? (rainbow() & 0xFFFFFF) : COLORS[(int) HIT_SEL.value]) : 0xFF0000;
        if (want != hitApplied) {
            overlay.autismclient$apply(want);
            hitApplied = want;
        }
    }

    private static final int[] COLORS = {0xFFFFFF, 0xFF3B3B, 0xFF9A2E, 0xFFE83B, 0x3BFF5A, 0x3BF0FF, 0x3B6BFF, 0xB03BFF, 0xFF6EC7, 0x000000};

    private static String[] COLOR_NAMES() {
        return new String[] {"White", "Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Purple", "Pink", "Black"};
    }

    private Modules() {}

    public static int rainbow() {
        float h = (System.currentTimeMillis() % 3000L) / 3000.0f * 6.0f;
        int i = (int) h;
        float f = h - i;
        float q = 1.0f - f;
        float r;
        float g;
        float b;
        switch (i % 6) {
            case 0: r = 1; g = f; b = 0; break;
            case 1: r = q; g = 1; b = 0; break;
            case 2: r = 0; g = 1; b = f; break;
            case 3: r = 0; g = q; b = 1; break;
            case 4: r = f; g = 0; b = 1; break;
            default: r = 1; g = 0; b = q; break;
        }
        return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    public static int pickColor(Module color, Module rainbow) {
        if (rainbow.enabled) {
            return rainbow();
        }
        return 0xFF000000 | COLORS[(int) color.value];
    }

    public static int skyColor() {
        int[] p = SKY_PRESETS[(int) SKY_STYLE.value];
        double t = SKY_TONE.value / 50.0;
        int r = Math.min(255, (int) (p[0] * t));
        int g = Math.min(255, (int) (p[1] * t));
        int b = Math.min(255, (int) (p[2] * t));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    public static void apply(Module m) {
        if (m == FOV) {
            MinecraftClient.getInstance().options.getFov().setValue((int) m.value);
        }
    }

    public static void tick(MinecraftClient client) {
        updateHit();
        ClientPlayerEntity p = client.player;
        if (p == null) {
            return;
        }
        if (FULLBRIGHT.enabled) {
            StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 240) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 520, 0, false, false, false));
            }
            nightVisionApplied = true;
        } else if (nightVisionApplied) {
            p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            nightVisionApplied = false;
        }
        if (SPRINT.enabled && client.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision) {
            p.setSprinting(true);
        }
    }
}
