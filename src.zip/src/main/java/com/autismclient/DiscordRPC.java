package com.autismclient;

import com.google.gson.JsonObject;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.StandardProtocolFamily;
import java.net.UnixDomainSocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.Channels;
import java.nio.channels.SocketChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;

/**
 * Minimal Discord Rich Presence over Discord's local IPC. No extra libraries needed.
 * Set "discordAppId" in config/autismclient.json to your Discord application id.
 * Upload an art asset named "logo" in the Discord developer portal for the big image.
 */
public final class DiscordRPC {
    private static final long START = System.currentTimeMillis() / 1000L;
    private static volatile boolean running = false;

    private static InputStream in;
    private static OutputStream out;
    private static Runnable closer;

    private DiscordRPC() {}

    public static void start() {
        if (running) {
            return;
        }
        running = true;
        Thread t = new Thread(DiscordRPC::loop, "OblivionX-RPC");
        t.setDaemon(true);
        t.start();
    }

    public static void stop() {
        running = false;
        close();
    }

    private static void loop() {
        boolean connected = false;
        while (running) {
            try {
                String id = Config.discordAppId == null ? "" : Config.discordAppId.trim();
                boolean want = Modules.DISCORD.enabled && id.matches("\\d{15,25}");
                if (!want) {
                    if (connected) {
                        close();
                        connected = false;
                    }
                    Thread.sleep(3000L);
                    continue;
                }
                if (!connected) {
                    connect(id);
                    connected = true;
                }
                sendActivity();
                Thread.sleep(15000L);
            } catch (InterruptedException e) {
                return;
            } catch (Exception e) {
                close();
                connected = false;
                try {
                    Thread.sleep(10000L);
                } catch (InterruptedException ie) {
                    return;
                }
            }
        }
        close();
    }

    private static void close() {
        Runnable c = closer;
        closer = null;
        in = null;
        out = null;
        if (c != null) {
            c.run();
        }
    }

    private static void open() throws IOException {
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("win")) {
            for (int i = 0; i < 10; i++) {
                try {
                    final RandomAccessFile raf = new RandomAccessFile("\\\\?\\pipe\\discord-ipc-" + i, "rw");
                    in = new InputStream() {
                        @Override
                        public int read() throws IOException {
                            return raf.read();
                        }

                        @Override
                        public int read(byte[] b, int off, int len) throws IOException {
                            return raf.read(b, off, len);
                        }
                    };
                    out = new OutputStream() {
                        @Override
                        public void write(int b) throws IOException {
                            raf.write(b);
                        }

                        @Override
                        public void write(byte[] b, int off, int len) throws IOException {
                            raf.write(b, off, len);
                        }
                    };
                    closer = () -> {
                        try {
                            raf.close();
                        } catch (IOException ignored) {
                        }
                    };
                    return;
                } catch (IOException ignored) {
                }
            }
            throw new IOException("Discord not running");
        }

        String[] bases = {
            System.getenv("XDG_RUNTIME_DIR"), System.getenv("TMPDIR"), System.getenv("TMP"), System.getenv("TEMP"), "/tmp"
        };
        String[] subs = {"", "snap.discord", "app/com.discordapp.Discord"};
        for (String base : bases) {
            if (base == null || base.isEmpty()) {
                continue;
            }
            for (String sub : subs) {
                for (int i = 0; i < 10; i++) {
                    Path path = Path.of(base, sub, "discord-ipc-" + i);
                    if (!Files.exists(path)) {
                        continue;
                    }
                    try {
                        final SocketChannel ch = SocketChannel.open(StandardProtocolFamily.UNIX);
                        ch.connect(UnixDomainSocketAddress.of(path));
                        in = Channels.newInputStream(ch);
                        out = Channels.newOutputStream(ch);
                        closer = () -> {
                            try {
                                ch.close();
                            } catch (IOException ignored) {
                            }
                        };
                        return;
                    } catch (IOException ignored) {
                    }
                }
            }
        }
        throw new IOException("Discord not running");
    }

    private static void write(int op, String json) throws IOException {
        byte[] d = json.getBytes(StandardCharsets.UTF_8);
        ByteBuffer b = ByteBuffer.allocate(8 + d.length).order(ByteOrder.LITTLE_ENDIAN);
        b.putInt(op).putInt(d.length).put(d);
        out.write(b.array());
        out.flush();
    }

    private static String read() throws IOException {
        byte[] h = in.readNBytes(8);
        if (h.length < 8) {
            throw new EOFException();
        }
        ByteBuffer hb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN);
        hb.getInt();
        int len = hb.getInt();
        if (len < 0 || len > 1 << 20) {
            throw new IOException("bad frame");
        }
        return new String(in.readNBytes(len), StandardCharsets.UTF_8);
    }

    private static void connect(String id) throws IOException {
        open();
        JsonObject hs = new JsonObject();
        hs.addProperty("v", 1);
        hs.addProperty("client_id", id);
        write(0, hs.toString());
        read();
    }

    private static void sendActivity() throws IOException {
        MinecraftClient mc = MinecraftClient.getInstance();
        String details;
        if (mc.world == null) {
            details = "In the menus";
        } else if (mc.isInSingleplayer()) {
            details = "Playing singleplayer";
        } else {
            details = "Playing multiplayer";
        }
        int on = 0;
        for (Module m : Modules.ALL) {
            if (m.enabled && !m.slider) {
                on++;
            }
        }

        JsonObject ts = new JsonObject();
        ts.addProperty("start", START);
        JsonObject assets = new JsonObject();
        assets.addProperty("large_image", "logo");
        assets.addProperty("large_text", "Oblivion X");
        JsonObject act = new JsonObject();
        act.addProperty("details", details);
        act.addProperty("state", on + " modules enabled");
        act.add("timestamps", ts);
        act.add("assets", assets);
        JsonObject args = new JsonObject();
        args.addProperty("pid", ProcessHandle.current().pid());
        args.add("activity", act);
        JsonObject cmd = new JsonObject();
        cmd.addProperty("cmd", "SET_ACTIVITY");
        cmd.add("args", args);
        cmd.addProperty("nonce", UUID.randomUUID().toString());
        write(1, cmd.toString());
        read();
    }
}
