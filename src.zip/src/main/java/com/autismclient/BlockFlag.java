package com.autismclient;

public interface BlockFlag {
    boolean autismclient$isBlock();

    void autismclient$setBlock(boolean block);
}
