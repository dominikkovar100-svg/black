package com.autismclient;

import java.util.ArrayDeque;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public final class HudRenderer {
    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public static int armorX = -1;
    public static int armorY = -1;
    public static final int ARMOR_W = 46;
    public static final int ARMOR_H = 78;

    public static int keyX = -1;
    public static int keyY = -1;
    public static final int KEY_W = 64;
    public static final int KEY_H = 80;

    private static final float[] KA = new float[7];
    private static final ArrayDeque<Long> LCLICKS = new ArrayDeque<>();
    private static final ArrayDeque<Long> RCLICKS = new ArrayDeque<>();
    private static boolean lPrev = false;
    private static boolean rPrev = false;
    private static long lastNano = System.nanoTime();

    private HudRenderer() {}

    public static void clampKeys(int w, int h) {
        if (keyX < 0) {
            keyX = 10;
        }
        if (keyY < 0) {
            keyY = h - KEY_H - 20;
        }
        keyX = Math.max(0, Math.min(w - KEY_W, keyX));
        keyY = Math.max(0, Math.min(h - KEY_H, keyY));
    }

    public static void clampArmor(int w, int h) {
        if (armorX < 0) {
            armorX = w - 58;
        }
        if (armorY < 0) {
            armorY = h / 2 - 40;
        }
        armorX = Math.max(0, Math.min(w - ARMOR_W, armorX));
        armorY = Math.max(0, Math.min(h - ARMOR_H, armorY));
    }

    public static void draw(DrawContext g) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) {
            return;
        }
        if (Modules.ARMOR_HUD.enabled) {
            drawArmor(g, mc);
        }
        if (Modules.KEYSTROKES.enabled) {
            drawKeys(g, mc);
        }
        if (Modules.CROSSHAIR.enabled && mc.currentScreen == null && mc.options.getPerspective().isFirstPerson()) {
            drawCrosshair(g);
        }
    }

    private static void drawArmor(DrawContext g, MinecraftClient mc) {
        int w = g.getScaledWindowWidth();
        int h = g.getScaledWindowHeight();
        clampArmor(w, h);
        int x = armorX;
        int y = armorY;
        for (int i = 0; i < ARMOR.length; i++) {
            ItemStack s = mc.player.getEquippedStack(ARMOR[i]);
            if (s.isEmpty()) {
                continue;
            }
            int iy = y + i * 20;
            g.drawItem(s, x, iy);
            g.drawStackOverlay(mc.textRenderer, s, x, iy);
            if (Modules.ARMOR_TEXT.enabled && s.isDamageable()) {
                int max = s.getMaxDamage();
                int pct = max <= 0 ? 100 : (max - s.getDamage()) * 100 / max;
                int col = pct > 50 ? 0xFF55FF55 : (pct > 25 ? 0xFFFFFF55 : 0xFFFF5555);
                g.drawText(mc.textRenderer, pct + "%", x + 19, iy + 4, col, true);
            }
        }
    }

    private static void drawCrosshair(DrawContext g) {
        int cx = g.getScaledWindowWidth() / 2;
        int cy = g.getScaledWindowHeight() / 2;
        int s = (int) Modules.CH_SIZE.value;
        int c = Modules.pickColor(Modules.CH_COLOR, Modules.CH_RAINBOW);
        switch ((int) Modules.CH_STYLE.value) {
            case 0: {
                int d = Math.max(1, s / 2);
                int x0 = cx - d / 2;
                int y0 = cy - d / 2;
                g.fill(x0, y0, x0 + d, y0 + d, c);
                break;
            }
            case 1: {
                int r = s + 2;
                double lo = (r - 0.5) * (r - 0.5);
                double hi = (r + 0.5) * (r + 0.5);
                for (int dy = -r - 1; dy <= r + 1; dy++) {
                    for (int dx = -r - 1; dx <= r + 1; dx++) {
                        double d = dx * dx + dy * dy;
                        if (d >= lo && d < hi) {
                            g.fill(cx + dx, cy + dy, cx + dx + 1, cy + dy + 1, c);
                        }
                    }
                }
                break;
            }
            case 2: {
                for (int i = -s; i <= s; i++) {
                    g.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, c);
                    g.fill(cx + i, cy - i, cx + i + 1, cy - i + 1, c);
                }
                break;
            }
            case 3: {
                int gap = 2;
                g.fill(cx - gap - s, cy, cx - gap, cy + 1, c);
                g.fill(cx + gap + 1, cy, cx + gap + 1 + s, cy + 1, c);
                g.fill(cx, cy - gap - s, cx + 1, cy - gap, c);
                g.fill(cx, cy + gap + 1, cx + 1, cy + gap + 1 + s, c);
                break;
            }
            default: {
                int r = s + 1;
                g.fill(cx - r, cy - r, cx + r + 1, cy - r + 1, c);
                g.fill(cx - r, cy + r, cx + r + 1, cy + r + 1, c);
                g.fill(cx - r, cy - r, cx - r + 1, cy + r + 1, c);
                g.fill(cx + r, cy - r, cx + r + 1, cy + r + 1, c);
                break;
            }
        }
    }

    private static int cps(ArrayDeque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000L) {
            q.pollFirst();
        }
        return q.size();
    }

    private static void key(DrawContext g, MinecraftClient mc, int x, int y, int w, int h, String label, String sub, float a) {
        int tr = 255;
        int tg = 255;
        int tb = 255;
        if (Modules.KEYS_RAINBOW.enabled) {
            int c = Modules.rainbow();
            tr = (c >> 16) & 0xFF;
            tg = (c >> 8) & 0xFF;
            tb = c & 0xFF;
        }
        for (int ring = 1; ring <= 3; ring++) {
            Glass.outline(g, x - ring, y - ring, w + 2 * ring, h + 2 * ring, 5 + ring, Glass.argb((int) (a * 45 * (1.0 - ring / 4.0)), tr, tg, tb));
        }
        Glass.rrect(g, x, y, w, h, 5, Glass.argb(125, 0, 0, 0));
        Glass.rrect(g, x, y, w, h, 5, Glass.argb((int) (18 + a * 95), tr, tg, tb));
        Glass.outline(g, x, y, w, h, 5, Glass.argb((int) (95 + a * 140), tr, tg, tb));
        g.fill(x + 5, y + 1, x + w - 5, y + 2, Glass.argb((int) (55 + a * 70), 255, 255, 255));
        int lw = mc.textRenderer.getWidth(label);
        if (sub == null) {
            g.drawText(mc.textRenderer, label, x + (w - lw) / 2, y + (h - 8) / 2, 0xFFFFFFFF, true);
        } else {
            g.drawText(mc.textRenderer, label, x + (w - lw) / 2, y + 3, 0xFFFFFFFF, true);
            int sw = mc.textRenderer.getWidth(sub);
            g.drawText(mc.textRenderer, sub, x + (w - sw) / 2, y + h - 11, 0xFFB8B8C8, false);
        }
    }

    private static void drawKeys(DrawContext g, MinecraftClient mc) {
        clampKeys(g.getScaledWindowWidth(), g.getScaledWindowHeight());
        long nowN = System.nanoTime();
        float dt = Math.min(0.1f, (nowN - lastNano) / 1.0e9f);
        lastNano = nowN;
        long now = System.currentTimeMillis();

        boolean l = mc.options.attackKey.isPressed();
        boolean r = mc.options.useKey.isPressed();
        if (l && !lPrev) {
            LCLICKS.addLast(now);
        }
        if (r && !rPrev) {
            RCLICKS.addLast(now);
        }
        lPrev = l;
        rPrev = r;

        boolean[] st = {
            mc.options.forwardKey.isPressed(), mc.options.leftKey.isPressed(), mc.options.backKey.isPressed(),
            mc.options.rightKey.isPressed(), l, r, mc.options.jumpKey.isPressed()
        };
        float f = 1.0f - (float) Math.exp(-dt * 18.0f);
        for (int i = 0; i < KA.length; i++) {
            KA[i] += ((st[i] ? 1.0f : 0.0f) - KA[i]) * f;
        }

        int x = keyX;
        int y = keyY;
        key(g, mc, x + 22, y, 20, 20, "W", null, KA[0]);
        key(g, mc, x, y + 22, 20, 20, "A", null, KA[1]);
        key(g, mc, x + 22, y + 22, 20, 20, "S", null, KA[2]);
        key(g, mc, x + 44, y + 22, 20, 20, "D", null, KA[3]);
        String ls = Modules.KEYS_CPS.enabled ? cps(LCLICKS, now) + " cps" : null;
        String rs = Modules.KEYS_CPS.enabled ? cps(RCLICKS, now) + " cps" : null;
        int mh = Modules.KEYS_CPS.enabled ? 24 : 20;
        key(g, mc, x, y + 44, 31, mh, "LMB", ls, KA[4]);
        key(g, mc, x + 33, y + 44, 31, mh, "RMB", rs, KA[5]);
        int sy = y + 44 + mh + 2;
        key(g, mc, x, sy, 64, 12, "", null, KA[6]);
        int bar = 18;
        g.fill(x + 32 - bar, sy + 5, x + 32 + bar, sy + 7, Glass.argb((int) (150 + KA[6] * 105), 255, 255, 255));
    }
}
