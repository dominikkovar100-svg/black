package com.autismclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public final class HudRenderer {
    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private HudRenderer() {}

    public static void draw(DrawContext g) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) {
            return;
        }
        if (Modules.ARMOR_HUD.enabled) {
            drawArmor(g, mc);
        }
        if (Modules.CROSSHAIR.enabled && mc.currentScreen == null && mc.options.getPerspective().isFirstPerson()) {
            drawCrosshair(g);
        }
    }

    private static void drawArmor(DrawContext g, MinecraftClient mc) {
        int w = g.getScaledWindowWidth();
        int h = g.getScaledWindowHeight();
        int x = w - 58;
        int y = h / 2 - 40;
        for (int i = 0; i < ARMOR.length; i++) {
            ItemStack s = mc.player.getEquippedStack(ARMOR[i]);
            if (s.isEmpty()) {
                continue;
            }
            int iy = y + i * 20;
            g.drawItem(s, x, iy);
            g.drawStackOverlay(mc.textRenderer, s, x, iy);
            if (Modules.ARMOR_TEXT.enabled && s.isDamageable()) {
                int max = s.getMaxDamage();
                int pct = max <= 0 ? 100 : (max - s.getDamage()) * 100 / max;
                int col = pct > 50 ? 0xFF55FF55 : (pct > 25 ? 0xFFFFFF55 : 0xFFFF5555);
                g.drawText(mc.textRenderer, pct + "%", x + 19, iy + 4, col, true);
            }
        }
    }

    private static void drawCrosshair(DrawContext g) {
        int cx = g.getScaledWindowWidth() / 2;
        int cy = g.getScaledWindowHeight() / 2;
        int s = (int) Modules.CH_SIZE.value;
        int c = Modules.pickColor(Modules.CH_COLOR, Modules.CH_RAINBOW);
        switch ((int) Modules.CH_STYLE.value) {
            case 0: {
                int d = Math.max(1, s / 2);
                int x0 = cx - d / 2;
                int y0 = cy - d / 2;
                g.fill(x0, y0, x0 + d, y0 + d, c);
                break;
            }
            case 1: {
                int r = s + 2;
                int n = r * 10;
                for (int i = 0; i < n; i++) {
                    double a = (Math.PI * 2.0 * i) / n;
                    int px = cx + (int) Math.round(Math.cos(a) * r);
                    int py = cy + (int) Math.round(Math.sin(a) * r);
                    g.fill(px, py, px + 1, py + 1, c);
                }
                break;
            }
            case 2: {
                for (int i = -s; i <= s; i++) {
                    g.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, c);
                    g.fill(cx + i, cy - i, cx + i + 1, cy - i + 1, c);
                }
                break;
            }
            case 3: {
                int gap = 2;
                g.fill(cx - gap - s, cy, cx - gap, cy + 1, c);
                g.fill(cx + gap + 1, cy, cx + gap + 1 + s, cy + 1, c);
                g.fill(cx, cy - gap - s, cx + 1, cy - gap, c);
                g.fill(cx, cy + gap + 1, cx + 1, cy + gap + 1 + s, c);
                break;
            }
            default: {
                int r = s + 1;
                g.fill(cx - r, cy - r, cx + r + 1, cy - r + 1, c);
                g.fill(cx - r, cy + r, cx + r + 1, cy + r + 1, c);
                g.fill(cx - r, cy - r, cx - r + 1, cy + r + 1, c);
                g.fill(cx + r, cy - r, cx + r + 1, cy + r + 1, c);
                break;
            }
        }
    }
}
