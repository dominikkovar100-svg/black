package com.autismclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class AutismClient implements ClientModInitializer {
    private boolean keyDown = false;

    @Override
    public void onInitializeClient() {
        Config.load();
        DiscordRPC.start();
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            Config.save();
            DiscordRPC.stop();
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (Config.fovPending && client.options != null) {
                Config.fovPending = false;
                Modules.apply(Modules.FOV);
            }
            Modules.tick(client);
            FreeLook.tick(client);
            pollOpenKey(client);
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            for (String name : new String[] {"ac", "ox", "oblivion", "autismclient"}) {
                dispatcher.register(ClientCommandManager.literal(name).executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new GlassScreen()));
                    return 1;
                }).then(ClientCommandManager.literal("save").executes(ctx -> {
                    Config.save();
                    ctx.getSource().sendFeedback(Text.literal("Oblivion X config saved"));
                    return 1;
                })).then(ClientCommandManager.literal("reload").executes(ctx -> {
                    Config.load();
                    ctx.getSource().sendFeedback(Text.literal("Oblivion X config reloaded"));
                    return 1;
                })));
            }
        });
    }

    private void pollOpenKey(MinecraftClient client) {
        long window = client.getWindow().getHandle();
        boolean down = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (down && !keyDown && client.currentScreen == null && client.player != null) {
            client.setScreen(new GlassScreen());
        }
        keyDown = down;
    }
}
