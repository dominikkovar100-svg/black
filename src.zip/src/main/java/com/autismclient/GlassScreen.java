package com.autismclient;

import java.util.List;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class GlassScreen extends Screen {
    private static final int ROW = 26;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int DIM = 0xFFC4C4CE;

    private static String tab = "Visuals";
    private Module dragging = null;
    private int dragBox = 0;
    private int grabX, grabY;
    private int px, py, pw, ph, side;
    private float openT = 0.0f;
    private boolean closing = false;
    private long last = System.nanoTime();
    private float tabT = 0.0f;
    private float pillY = -1.0f;
    private float closeHov = 0.0f;
    private final float[] catHov = new float[16];
    private final float[] catSel = new float[16];
    private final float[] rowHov = new float[48];

    public GlassScreen() {
        super(Text.literal("AutismClient"));
    }

    @Override
    protected void init() {
        pw = Math.min(width - 12, 420);
        ph = Math.min(height - 12, 250);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        side = Math.max(70, Math.min(100, pw / 3));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        closing = true;
    }

    @Override
    public void tick() {
        super.tick();
        if (closing && openT <= 0.0f) {
            super.close();
        }
    }

    private static int argb(int a, int r, int g, int b) {
        return Glass.argb(a, r, g, b);
    }

    private static int ins(int i, int r) {
        double d = r - i - 0.5;
        return r - (int) Math.round(Math.sqrt(Math.max(0.0, r * r - d * d)));
    }

    private static void rrect(DrawContext g, int x, int y, int w, int h, int r, int c) {
        int rr = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        g.fill(x, y + rr, x + w, y + h - rr, c);
        for (int i = 0; i < rr; i++) {
            int in = ins(i, rr);
            g.fill(x + in, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, c);
        }
    }

    private static void outline(DrawContext g, int x, int y, int w, int h, int r, int c) {
        int rr = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        g.fill(x + rr, y, x + w - rr, y + 1, c);
        g.fill(x + rr, y + h - 1, x + w - rr, y + h, c);
        g.fill(x, y + rr, x + 1, y + h - rr, c);
        g.fill(x + w - 1, y + rr, x + w, y + h - rr, c);
        for (int i = 0; i < rr; i++) {
            int in = ins(i, rr);
            int span = (i == 0) ? rr : Math.max(in + 1, ins(i - 1, rr));
            g.fill(x + in, y + i, x + span, y + i + 1, c);
            g.fill(x + w - span, y + i, x + w - in, y + i + 1, c);
            g.fill(x + in, y + h - 1 - i, x + span, y + h - i, c);
            g.fill(x + w - span, y + h - 1 - i, x + w - in, y + h - i, c);
        }
    }

    private static void glow(DrawContext g, int x, int y, int w, int h, int r, int rings, int strength) {
        if (!Modules.GLOW.enabled) {
            return;
        }
        for (int k = 1; k <= rings; k++) {
            outline(g, x - k, y - k, w + 2 * k, h + 2 * k, r + k, argb(strength - k * (strength / (rings + 1)), 255, 255, 255));
        }
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private List<Module> current() {
        return Modules.ALL.stream().filter(m -> m.category.equals(tab)).toList();
    }

    private int rowY(int n) {
        return py + 34 + n * (ROW + 6);
    }

    private int cx() {
        return px + side + 10;
    }

    private int cw() {
        return pw - side - 20;
    }

    private int trackW() {
        return Math.max(40, Math.min(80, cw() / 3));
    }

    private int trackX() {
        return cx() + cw() - 10 - trackW();
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1.0e9f);
        last = now;
        openT = closing ? Math.max(0.0f, openT - dt / 0.18f) : Math.min(1.0f, openT + dt / 0.32f);
        tabT = Math.min(1.0f, tabT + dt / 0.5f);
        float e = Anim.ease(openT);

        Glass.alpha = e;
        super.render(g, mx, my, delta);

        int a = (int) (Modules.OPACITY.value / 100.0 * 255.0);
        float sc = 0.92f + 0.08f * e;
        float pcx = px + pw / 2.0f;
        float pcy = py + ph / 2.0f;
        var mat = g.getMatrices();
        mat.pushMatrix();
        mat.translate(pcx, pcy + (1.0f - e) * 12.0f);
        mat.scale(sc, sc);
        mat.translate(-pcx, -pcy);

        glow(g, px, py, pw, ph, 12, 6, 48);
        rrect(g, px, py, pw, ph, 12, argb(95, 10, 10, 16));
        rrect(g, px, py, pw, ph, 12, argb(a, 255, 255, 255));
        outline(g, px, py, pw, ph, 12, argb(130, 255, 255, 255));
        g.fill(px + 14, py + 1, px + pw - 14, py + 2, argb(120, 255, 255, 255));

        Glass.text(g, textRenderer, "AutismClient", px + 12, py + 12, WHITE, true);
        g.fill(px + side, py + 30, px + side + 1, py + ph - 12, argb(45, 255, 255, 255));

        int closeX = px + pw - 24;
        int closeY = py + 8;
        boolean closeOver = inside(mx, my, closeX, closeY, 16, 16);
        closeHov = Anim.approach(closeHov, closeOver ? 1.0f : 0.0f, 16.0f, dt);
        rrect(g, closeX, closeY, 16, 16, 5, argb((int) (35 + 55 * closeHov), 255, 255, 255));
        Glass.text(g, textRenderer, "x", closeX + 6, closeY + 4, WHITE, true);

        int selIdx = 0;
        for (int i = 0; i < Modules.CATEGORIES.length; i++) {
            if (Modules.CATEGORIES[i].equals(tab)) {
                selIdx = i;
            }
        }
        float pillTarget = py + 34 + selIdx * (ROW + 2);
        if (pillY < 0.0f) {
            pillY = pillTarget;
        }
        pillY = Anim.approach(pillY, pillTarget, 18.0f, dt);
        int pbx = px + 8;
        int pby = Math.round(pillY);
        int pbw = side - 14;
        glow(g, pbx, pby, pbw, ROW, 8, 3, 40);
        rrect(g, pbx, pby, pbw, ROW, 8, argb(65, 255, 255, 255));
        outline(g, pbx, pby, pbw, ROW, 8, argb(170, 255, 255, 255));

        for (int i = 0; i < Modules.CATEGORIES.length; i++) {
            String c = Modules.CATEGORIES[i];
            int bx = px + 8;
            int by = py + 34 + i * (ROW + 2);
            boolean sel = c.equals(tab);
            boolean hov = inside(mx, my, bx, by, pbw, ROW);
            catHov[i] = Anim.approach(catHov[i], hov ? 1.0f : 0.0f, 16.0f, dt);
            catSel[i] = Anim.approach(catSel[i], sel ? 1.0f : 0.0f, 14.0f, dt);
            int ha = (int) (28 * catHov[i] * (1.0f - catSel[i]));
            if (ha > 0) {
                rrect(g, bx, by, pbw, ROW, 8, argb(ha, 255, 255, 255));
            }
            Glass.text(g, textRenderer, c, bx + 8 + (int) (3 * catSel[i]), by + (ROW - 8) / 2, Anim.mix(DIM, WHITE, catSel[i]), sel);
        }

        Glass.alpha = e * Anim.ease(tabT * 2.0f);
        Glass.text(g, textRenderer, tab, cx(), py + 14, WHITE, true);

        List<Module> list = current();
        for (int n = 0; n < list.size(); n++) {
            Module m = list.get(n);
            float ra = Anim.ease(tabT * 1.8f - n * 0.08f);
            if (ra <= 0.0f) {
                continue;
            }
            Glass.alpha = e * ra;
            int ry = rowY(n);
            boolean hov = inside(mx, my, cx(), ry, cw(), ROW);
            rowHov[n] = Anim.approach(rowHov[n], hov ? 1.0f : 0.0f, 16.0f, dt);
            if (m.anim < 0.0f) {
                m.anim = m.enabled ? 1.0f : 0.0f;
            }
            m.anim = Anim.approach(m.anim, m.enabled ? 1.0f : 0.0f, 16.0f, dt);
            if (m.shown < 0.0f) {
                m.shown = (float) m.ratio();
            }
            m.shown = Anim.approach(m.shown, (float) m.ratio(), 22.0f, dt);

            mat.pushMatrix();
            mat.translate((1.0f - ra) * 16.0f, 0.0f);
            rrect(g, cx(), ry, cw(), ROW, 8, argb((int) (22 + 16 * rowHov[n]), 255, 255, 255));
            outline(g, cx(), ry, cw(), ROW, 8, argb((int) (55 + 40 * rowHov[n]), 255, 255, 255));
            String label = m.name;
            if (m.slider) {
                label = m.labels != null ? m.name + "  " + m.labels[(int) (m.value - m.min)] : m.name + "  " + (int) m.value;
            }
            Glass.text(g, textRenderer, label, cx() + 8, ry + (ROW - 8) / 2, WHITE, false);

            if (m.slider) {
                int tx = trackX();
                int ty = ry + ROW / 2 - 1;
                int tw = trackW();
                g.fill(tx, ty, tx + tw, ty + 3, argb(70, 255, 255, 255));
                int fw = (int) (tw * m.shown);
                g.fill(tx, ty, tx + fw, ty + 3, argb(255, 255, 255, 255));
                glow(g, tx + fw - 4, ty - 3, 8, 8, 4, 3, 60);
                rrect(g, tx + fw - 4, ty - 3, 8, 8, 4, argb(255, 255, 255, 255));
            } else {
                float k = m.anim;
                int tx = cx() + cw() - 10 - 28;
                int ty = ry + (ROW - 14) / 2;
                if (k > 0.02f) {
                    glow(g, tx, ty, 28, 14, 7, 3, (int) (60 * k));
                }
                rrect(g, tx, ty, 28, 14, 7, argb((int) (25 + 85 * k), 255, 255, 255));
                outline(g, tx, ty, 28, 14, 7, argb((int) (110 + 110 * k), 255, 255, 255));
                rrect(g, tx + 2 + (int) (14 * k), ty + 2, 10, 10, 5, argb((int) (160 + 95 * k), 255, 255, 255));
            }
            mat.popMatrix();
        }
        mat.popMatrix();

        Glass.alpha = e;
        drawBoxes(g, mx, my);
        Glass.alpha = 1.0f;
    }

    private int boxAt(double mx, double my) {
        if (Modules.KEYSTROKES.enabled) {
            HudRenderer.clampKeys(width, height);
            if (inside(mx, my, HudRenderer.keyX, HudRenderer.keyY, HudRenderer.KEY_W, HudRenderer.KEY_H)) {
                return 2;
            }
        }
        if (Modules.ARMOR_HUD.enabled) {
            HudRenderer.clampArmor(width, height);
            if (inside(mx, my, HudRenderer.armorX, HudRenderer.armorY, HudRenderer.ARMOR_W, HudRenderer.ARMOR_H)) {
                return 1;
            }
        }
        return 0;
    }

    private void drawBox(DrawContext g, int x, int y, int w, int h, boolean hot, String label) {
        rrect(g, x, y, w, h, 6, argb(hot ? 50 : 25, 255, 255, 255));
        outline(g, x, y, w, h, 6, argb(hot ? 230 : 130, 255, 255, 255));
        Glass.text(g, textRenderer, label, x + 6, y + h - 11, WHITE, true);
    }

    private void drawBoxes(DrawContext g, int mx, int my) {
        int over = boxAt(mx, my);
        if (Modules.ARMOR_HUD.enabled) {
            HudRenderer.clampArmor(width, height);
            drawBox(g, HudRenderer.armorX, HudRenderer.armorY, HudRenderer.ARMOR_W, HudRenderer.ARMOR_H, dragBox == 1 || (dragBox == 0 && over == 1), "armor");
        }
        if (Modules.KEYSTROKES.enabled) {
            HudRenderer.clampKeys(width, height);
            drawBox(g, HudRenderer.keyX, HudRenderer.keyY, HudRenderer.KEY_W, HudRenderer.KEY_H, dragBox == 2 || (dragBox == 0 && over == 2), "keys");
        }
    }

    private void updateSlider(Module m, double x) {
        m.setRatio((x - trackX()) / trackW());
        Modules.apply(m);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (closing) {
            return true;
        }
        if (click.button() != 0) {
            return super.mouseClicked(click, doubled);
        }
        double mx = click.x();
        double my = click.y();

        int hit = boxAt(mx, my);
        if (hit != 0) {
            dragBox = hit;
            grabX = (int) mx - (hit == 1 ? HudRenderer.armorX : HudRenderer.keyX);
            grabY = (int) my - (hit == 1 ? HudRenderer.armorY : HudRenderer.keyY);
            return true;
        }
        if (inside(mx, my, px + pw - 24, py + 8, 16, 16)) {
            close();
            return true;
        }
        for (int i = 0; i < Modules.CATEGORIES.length; i++) {
            if (inside(mx, my, px + 8, py + 34 + i * (ROW + 2), side - 14, ROW)) {
                if (!tab.equals(Modules.CATEGORIES[i])) {
                    tab = Modules.CATEGORIES[i];
                    tabT = 0.0f;
                    java.util.Arrays.fill(rowHov, 0.0f);
                }
                return true;
            }
        }
        List<Module> list = current();
        for (int n = 0; n < list.size(); n++) {
            Module m = list.get(n);
            if (inside(mx, my, cx(), rowY(n), cw(), ROW)) {
                if (m.slider) {
                    dragging = m;
                    updateSlider(m, mx);
                } else {
                    m.enabled = !m.enabled;
                    Modules.apply(m);
                }
                return true;
            }
        }
        if (inside(mx, my, px, py, pw, ph)) {
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragBox == 1) {
            HudRenderer.armorX = (int) click.x() - grabX;
            HudRenderer.armorY = (int) click.y() - grabY;
            HudRenderer.clampArmor(width, height);
            return true;
        }
        if (dragBox == 2) {
            HudRenderer.keyX = (int) click.x() - grabX;
            HudRenderer.keyY = (int) click.y() - grabY;
            HudRenderer.clampKeys(width, height);
            return true;
        }
        if (dragging != null) {
            updateSlider(dragging, click.x());
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        dragBox = 0;
        return super.mouseReleased(click);
    }
}
