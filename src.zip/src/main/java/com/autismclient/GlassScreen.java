package com.autismclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class GlassScreen extends Screen {
    private static final int PW = 112;
    private static final int HEAD = 20;
    private static final int ROW = 13;
    private static final int PAD = 3;
    private static final int GAP = 7;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int DIM = 0xFFCDBDF0;
    private static final int CHEV = 0xFFA592D2;

    private static final class Panel {
        final String cat;
        final List<Module> mods;
        final int order;
        float x;
        float y;
        boolean open = true;
        float openAnim = 1.0f;
        int scroll = 0;
        final float[] hov;

        Panel(String cat, List<Module> mods, int order) {
            this.cat = cat;
            this.mods = mods;
            this.order = order;
            this.hov = new float[Math.max(1, mods.size())];
        }
    }

    private static List<Panel> panels = null;
    private static boolean laidOut = false;

    private Panel dragPanel = null;
    private int panelGrabX, panelGrabY;
    private Panel sliderPanel = null;
    private Module dragging = null;
    private int dragBox = 0;
    private int boxGrabX, boxGrabY;

    private float openT = 0.0f;
    private boolean closing = false;
    private long last = System.nanoTime();
    private float closeHov = 0.0f;

    public GlassScreen() {
        super(Text.literal("AutismClient"));
    }

    @Override
    protected void init() {
        if (panels == null) {
            panels = new ArrayList<>();
            int idx = 0;
            for (String c : Modules.CATEGORIES) {
                List<Module> mods = Modules.ALL.stream().filter(m -> m.category.equals(c)).toList();
                panels.add(new Panel(c, mods, idx++));
            }
        }
        if (!laidOut) {
            layout();
            for (Panel p : panels) {
                if (Config.panels.has(p.cat)) {
                    JsonArray a = Config.panels.getAsJsonArray(p.cat);
                    p.x = a.get(0).getAsFloat();
                    p.y = a.get(1).getAsFloat();
                    p.open = a.get(2).getAsInt() != 0;
                    p.openAnim = p.open ? 1.0f : 0.0f;
                }
            }
            laidOut = true;
        }
        for (Panel p : panels) {
            clampPanel(p);
        }
    }

    public static void exportPanels(JsonObject out) {
        if (panels == null) {
            return;
        }
        for (Panel p : panels) {
            JsonArray a = new JsonArray();
            a.add(p.x);
            a.add(p.y);
            a.add(p.open ? 1 : 0);
            out.add(p.cat, a);
        }
    }

    private void layout() {
        int cols = Math.max(1, (width - GAP) / (PW + GAP));
        float totalW = cols * PW + (cols - 1) * GAP;
        float startX = (width - totalW) / 2.0f;
        float[] colH = new float[cols];
        for (int i = 0; i < cols; i++) {
            colH[i] = 10;
        }
        for (Panel p : panels) {
            int c = 0;
            for (int i = 1; i < cols; i++) {
                if (colH[i] < colH[c]) {
                    c = i;
                }
            }
            p.x = startX + c * (PW + GAP);
            p.y = colH[c];
            int avail = height - 8 - (int) p.y;
            int full = HEAD + fullBody(p);
            if (avail < HEAD + PAD * 2 + ROW * 2) {
                p.open = false;
                p.openAnim = 0.0f;
                colH[c] += HEAD + GAP;
            } else {
                colH[c] += Math.min(full, avail) + GAP;
            }
        }
    }

    private void clampPanel(Panel p) {
        p.x = Math.max(0, Math.min(width - PW, p.x));
        p.y = Math.max(0, Math.min(height - HEAD - 2, p.y));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        closing = true;
    }

    @Override
    public void tick() {
        super.tick();
        if (closing && openT <= 0.0f) {
            Config.save();
            super.close();
        }
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static int argb(int a, int r, int g, int b) {
        return Glass.argb(a, r, g, b);
    }

    private static void rrect(DrawContext g, int x, int y, int w, int h, int r, int c) {
        Glass.rrect(g, x, y, w, h, r, c);
    }

    private static void outline(DrawContext g, int x, int y, int w, int h, int r, int c) {
        Glass.outline(g, x, y, w, h, r, c);
    }

    private static void glow(DrawContext g, int x, int y, int w, int h, int r, int rings, int strength, int cr, int cg, int cb) {
        if (!Modules.GLOW.enabled || strength <= 0) {
            return;
        }
        for (int k = 1; k <= rings; k++) {
            outline(g, x - k, y - k, w + 2 * k, h + 2 * k, r + k, argb(strength - k * (strength / (rings + 1)), cr, cg, cb));
        }
    }

    private int fullBody(Panel p) {
        return p.mods.size() * ROW + PAD * 2;
    }

    private int visBody(Panel p) {
        int full = fullBody(p);
        int maxH = Math.max(PAD * 2 + ROW * 2, height - (int) p.y - HEAD - 6);
        return Math.min(full, maxH);
    }

    private int bodyNow(Panel p) {
        return Math.round(visBody(p) * Anim.ease(p.openAnim));
    }

    private int maxScroll(Panel p) {
        int over = fullBody(p) - visBody(p);
        if (over <= 0) {
            return 0;
        }
        return ((over + ROW - 1) / ROW) * ROW;
    }

    private Panel panelAt(double mx, double my) {
        for (int i = panels.size() - 1; i >= 0; i--) {
            Panel p = panels.get(i);
            if (inside(mx, my, Math.round(p.x), Math.round(p.y), PW, HEAD + bodyNow(p))) {
                return p;
            }
        }
        return null;
    }

    private int rowAt(Panel p, double mx, double my) {
        int px = Math.round(p.x);
        int py = Math.round(p.y);
        int body = bodyNow(p);
        for (int n = 0; n < p.mods.size(); n++) {
            int ry = py + HEAD + PAD + n * ROW - p.scroll;
            if (ry >= py + HEAD + PAD && ry + ROW <= py + HEAD + body - PAD && inside(mx, my, px + 3, ry, PW - 6, ROW)) {
                return n;
            }
        }
        return -1;
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - last) / 1.0e9f);
        last = now;
        openT = closing ? Math.max(0.0f, openT - dt / 0.18f) : Math.min(1.0f, openT + dt / 0.45f);
        float e = Anim.ease(openT);

        Glass.alpha = e;
        super.render(g, mx, my, delta);
        drawBoxes(g, mx, my);

        var mat = g.getMatrices();
        Panel hovered = panelAt(mx, my);
        for (int i = 0; i < panels.size(); i++) {
            Panel p = panels.get(i);
            float st = Anim.ease(openT * 1.7f - p.order * 0.1f);
            if (st <= 0.0f) {
                continue;
            }
            Glass.alpha = e * st;
            mat.pushMatrix();
            mat.translate(0.0f, (1.0f - st) * 12.0f);
            drawPanel(g, p, mx, my, dt, hovered == p);
            mat.popMatrix();
        }

        Glass.alpha = e;
        int cx = width - 22;
        int cy = 6;
        boolean closeOver = inside(mx, my, cx, cy, 16, 16);
        closeHov = Anim.approach(closeHov, closeOver ? 1.0f : 0.0f, 16.0f, dt);
        rrect(g, cx, cy, 16, 16, 5, argb((int) (70 + 60 * closeHov), 110, 40, 210));
        outline(g, cx, cy, 16, 16, 5, argb(160, 190, 150, 255));
        Glass.text(g, textRenderer, "x", cx + 6, cy + 4, WHITE, true);

        String wm = "AutismClient";
        Glass.text(g, textRenderer, wm, (width - textRenderer.getWidth(wm)) / 2, height - 12, 0xFFB89CFF, false);
        Glass.alpha = 1.0f;
    }

    private void drawPanel(DrawContext g, Panel p, int mx, int my, float dt, boolean hoverPanel) {
        int x = Math.round(p.x);
        int y = Math.round(p.y);
        p.openAnim = Anim.approach(p.openAnim, p.open ? 1.0f : 0.0f, 14.0f, dt);
        if (Math.abs(p.openAnim - (p.open ? 1.0f : 0.0f)) < 0.002f) {
            p.openAnim = p.open ? 1.0f : 0.0f;
        }
        int ms = maxScroll(p);
        p.scroll = Math.max(0, Math.min(ms, p.scroll));
        int body = bodyNow(p);
        int h = HEAD + body;
        int a = (int) (Modules.OPACITY.value / 100.0 * 255.0);

        // panel shell: deep navy glass, soft blue glow, light-blue rim
        glow(g, x, y, PW, h, 8, 3, 52, 150, 70, 255);
        rrect(g, x, y, PW, h, 8, argb(212, 10, 4, 30));
        rrect(g, x, y, PW, h, 8, argb(a, 170, 120, 255));
        g.fillGradient(x + 3, y + 2, x + PW - 3, y + h - 2, argb(30, 130, 70, 230), argb(0, 60, 20, 120));
        outline(g, x, y, PW, h, 8, argb(195, 185, 150, 255));
        outline(g, x + 1, y + 1, PW - 2, h - 2, 7, argb(40, 230, 200, 255));

        sparkle(g, x, y, PW, h, p.order);

        // header
        g.fillGradient(x + 4, y + 2, x + PW - 4, y + HEAD - 1, argb(70, 160, 90, 255), argb(6, 80, 30, 160));
        g.fill(x + 8, y + 1, x + PW - 8, y + 2, argb(130, 235, 210, 255));

        rrect(g, x + 5, y + 4, 12, 12, 3, argb(235, 28, 10, 80));
        outline(g, x + 5, y + 4, 12, 12, 3, argb(210, 190, 150, 255));
        Glass.text(g, textRenderer, p.cat.substring(0, 1).toUpperCase(), x + 9, y + 6, WHITE, false);
        Glass.text(g, textRenderer, p.cat.toUpperCase(), x + 22, y + 6, WHITE, false);

        String badge = String.valueOf(p.mods.size());
        int bw = Math.max(14, textRenderer.getWidth(badge) + 8);
        int bx = x + PW - 19 - bw;
        rrect(g, bx, y + 5, bw, 10, 5, argb(215, 26, 8, 70));
        outline(g, bx, y + 5, bw, 10, 5, argb(150, 180, 140, 255));
        Glass.text(g, textRenderer, badge, bx + (bw - textRenderer.getWidth(badge)) / 2, y + 6, WHITE, false);
        Glass.text(g, textRenderer, p.open ? "v" : ">", x + PW - 13, y + 6, DIM, false);

        if (body <= 0) {
            return;
        }
        g.fill(x + 5, y + HEAD - 1, x + PW - 5, y + HEAD, argb(75, 190, 150, 255));

        for (int n = 0; n < p.mods.size(); n++) {
            int ry = y + HEAD + PAD + n * ROW - p.scroll;
            if (ry < y + HEAD + PAD || ry + ROW > y + HEAD + body - PAD) {
                continue;
            }
            Module m = p.mods.get(n);
            boolean over = hoverPanel && inside(mx, my, x + 3, ry, PW - 6, ROW);
            p.hov[n] = Anim.approach(p.hov[n], over ? 1.0f : 0.0f, 16.0f, dt);
            if (m.anim < 0.0f) {
                m.anim = m.enabled ? 1.0f : 0.0f;
            }
            m.anim = Anim.approach(m.anim, m.enabled ? 1.0f : 0.0f, 16.0f, dt);
            if (m.shown < 0.0f) {
                m.shown = (float) m.ratio();
            }
            m.shown = Anim.approach(m.shown, (float) m.ratio(), 22.0f, dt);

            int rx = x + 3;
            int rw = PW - 6;
            int rh = ROW - 1;
            String name = m.name.toUpperCase();
            if (m.slider) {
                String val = m.labels != null ? m.labels[(int) (m.value - m.min)].toUpperCase() : String.valueOf((int) m.value);
                int vw = textRenderer.getWidth(val);
                rrect(g, rx, ry, rw, rh, 3, argb((int) (44 + 26 * p.hov[n]), 130, 90, 230));
                int fw = (int) (rw * m.shown);
                if (fw > 4) {
                    rrect(g, rx, ry, fw, rh, 3, argb(235, 110, 40, 220));
                    g.fillGradient(rx + 2, ry + 1, rx + fw - 2, ry + rh - 1, argb(95, 225, 140, 255), argb(0, 90, 40, 220));
                }
                Glass.text(g, textRenderer, textRenderer.trimToWidth(name, rw - vw - 14), rx + 4, ry + 2, WHITE, false);
                Glass.text(g, textRenderer, val, rx + rw - vw - 4, ry + 2, WHITE, false);
            } else {
                float k = m.anim;
                int ha = (int) (38 * p.hov[n] * (1.0f - k));
                if (ha > 0) {
                    rrect(g, rx, ry, rw, rh, 3, argb(ha, 200, 160, 255));
                }
                if (k > 0.02f) {
                    rrect(g, rx, ry, rw, rh, 3, argb((int) (240 * k), 96, 34, 205));
                    g.fillGradient(rx + 1, ry + 1, rx + rw - 1, ry + rh - 1, argb((int) (160 * k), 215, 120, 255), argb((int) (24 * k), 70, 30, 200));
                    g.fill(rx + 3, ry, rx + rw - 3, ry + 1, argb((int) (130 * k), 245, 210, 255));
                }
                Glass.text(g, textRenderer, textRenderer.trimToWidth(name, rw - 16), rx + 4, ry + 2, Anim.mix(DIM, WHITE, k), false);
                Glass.text(g, textRenderer, ">", rx + rw - 9, ry + 2, Anim.mix(CHEV, WHITE, k), false);
            }
        }
    }

    private static void sparkle(DrawContext g, int x, int y, int w, int h, int seed) {
        double t = Galaxy.time();
        for (int i = 0; i < 9; i++) {
            int hx = (i * 37 + seed * 53) % (w - 8) + 4;
            int hy = (i * 61 + seed * 29) % Math.max(1, h - 8) + 4;
            double tw = 0.5 + 0.5 * Math.sin(t * (0.8 + i * 0.13) + i * 1.7 + seed);
            g.fill(x + hx, y + hy, x + hx + 1, y + hy + 1, argb((int) (40 + 90 * tw), 235, 225, 255));
        }
    }

    private int boxAt(double mx, double my) {
        if (Modules.KEYSTROKES.enabled) {
            HudRenderer.clampKeys(width, height);
            if (inside(mx, my, HudRenderer.keyX, HudRenderer.keyY, HudRenderer.KEY_W, HudRenderer.KEY_H)) {
                return 2;
            }
        }
        if (Modules.ARMOR_HUD.enabled) {
            HudRenderer.clampArmor(width, height);
            if (inside(mx, my, HudRenderer.armorX, HudRenderer.armorY, HudRenderer.ARMOR_W, HudRenderer.ARMOR_H)) {
                return 1;
            }
        }
        if (Modules.INV_HUD.enabled) {
            HudRenderer.clampInv(width, height);
            if (inside(mx, my, HudRenderer.invX, HudRenderer.invY, HudRenderer.INV_W, HudRenderer.INV_H)) {
                return 3;
            }
        }
        return 0;
    }

    private void drawBox(DrawContext g, int x, int y, int w, int h, boolean hot, String label) {
        rrect(g, x, y, w, h, 6, argb(hot ? 60 : 30, 170, 120, 255));
        outline(g, x, y, w, h, 6, argb(hot ? 235 : 135, 190, 150, 255));
        Glass.text(g, textRenderer, label, x + 6, y + h - 11, WHITE, true);
    }

    private void drawBoxes(DrawContext g, int mx, int my) {
        int over = boxAt(mx, my);
        if (Modules.ARMOR_HUD.enabled) {
            HudRenderer.clampArmor(width, height);
            drawBox(g, HudRenderer.armorX, HudRenderer.armorY, HudRenderer.ARMOR_W, HudRenderer.ARMOR_H, dragBox == 1 || (dragBox == 0 && over == 1), "armor");
        }
        if (Modules.INV_HUD.enabled) {
            HudRenderer.clampInv(width, height);
            drawBox(g, HudRenderer.invX, HudRenderer.invY, HudRenderer.INV_W, HudRenderer.INV_H, dragBox == 3 || (dragBox == 0 && over == 3), "inventory");
        }
        if (Modules.KEYSTROKES.enabled) {
            HudRenderer.clampKeys(width, height);
            drawBox(g, HudRenderer.keyX, HudRenderer.keyY, HudRenderer.KEY_W, HudRenderer.KEY_H, dragBox == 2 || (dragBox == 0 && over == 2), "keys");
        }
    }

    private void updateSlider(Module m, double x) {
        if (sliderPanel == null) {
            return;
        }
        m.setRatio((x - (sliderPanel.x + 3)) / (PW - 6));
        Modules.apply(m);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (closing) {
            return true;
        }
        double mx = click.x();
        double my = click.y();
        int button = click.button();

        if (button == 0 && inside(mx, my, width - 22, 6, 16, 16)) {
            close();
            return true;
        }

        for (int i = panels.size() - 1; i >= 0; i--) {
            Panel p = panels.get(i);
            int px = Math.round(p.x);
            int py = Math.round(p.y);
            if (!inside(mx, my, px, py, PW, HEAD + bodyNow(p))) {
                continue;
            }
            panels.remove(i);
            panels.add(p);
            if (my < py + HEAD) {
                if (button == 1 || mx > px + PW - 20) {
                    p.open = !p.open;
                    return true;
                }
                dragPanel = p;
                panelGrabX = (int) (mx - p.x);
                panelGrabY = (int) (my - p.y);
                return true;
            }
            if (button == 0) {
                int n = rowAt(p, mx, my);
                if (n >= 0) {
                    Module m = p.mods.get(n);
                    if (m.slider) {
                        dragging = m;
                        sliderPanel = p;
                        updateSlider(m, mx);
                    } else {
                        m.enabled = !m.enabled;
                        Modules.apply(m);
                    }
                }
            }
            return true;
        }

        if (button == 0) {
            int hit = boxAt(mx, my);
            if (hit != 0) {
                dragBox = hit;
                boxGrabX = (int) mx - (hit == 1 ? HudRenderer.armorX : (hit == 2 ? HudRenderer.keyX : HudRenderer.invX));
                boxGrabY = (int) my - (hit == 1 ? HudRenderer.armorY : (hit == 2 ? HudRenderer.keyY : HudRenderer.invY));
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (dragPanel != null) {
            dragPanel.x = (float) click.x() - panelGrabX;
            dragPanel.y = (float) click.y() - panelGrabY;
            clampPanel(dragPanel);
            return true;
        }
        if (dragBox == 1) {
            HudRenderer.armorX = (int) click.x() - boxGrabX;
            HudRenderer.armorY = (int) click.y() - boxGrabY;
            HudRenderer.clampArmor(width, height);
            return true;
        }
        if (dragBox == 3) {
            HudRenderer.invX = (int) click.x() - boxGrabX;
            HudRenderer.invY = (int) click.y() - boxGrabY;
            HudRenderer.clampInv(width, height);
            return true;
        }
        if (dragBox == 2) {
            HudRenderer.keyX = (int) click.x() - boxGrabX;
            HudRenderer.keyY = (int) click.y() - boxGrabY;
            HudRenderer.clampKeys(width, height);
            return true;
        }
        if (dragging != null) {
            updateSlider(dragging, click.x());
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        sliderPanel = null;
        dragPanel = null;
        dragBox = 0;
        return super.mouseReleased(click);
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        Panel p = panelAt(mouseX, mouseY);
        if (p != null && maxScroll(p) > 0) {
            p.scroll = Math.max(0, Math.min(maxScroll(p), p.scroll - (int) Math.signum(verticalAmount) * ROW));
            return true;
        }
        return false;
    }
}
