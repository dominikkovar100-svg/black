# AutismVisual

A client-side Fabric mod for Minecraft 1.21.11 with a touch-friendly click GUI for world visual settings.
Works with mobile launchers (PojavLauncher, Zalith, etc.) because it only uses vanilla rendering and widgets. Mobile players need a keyboard or on-screen key mapping for Right Shift.

Status: GUI shell only. Visual effects are not added yet.

## Usage
- Press Right Shift in-game to open the GUI (rebindable in Controls).
- Drag panel headers to move them, tap `+`/`-` to collapse.

## Building
Requires Java 21.

    gradle wrapper --gradle-version 9.2.1   # one time, creates ./gradlew
    ./gradlew build

The jar is written to `build/libs/`. Pushing to GitHub also builds it via Actions.

## Adding a toggle
In `AutismVisualClient`:

    ModuleManager.register(new Module("Name", "Sky"));

Then check `module.isEnabled()` where your effect lives. Categories are listed in `ModuleManager.CATEGORIES`.

## License
MIT
