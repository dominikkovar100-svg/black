package com.autismclient.mixin;

import com.autismclient.Modules;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SkyRendering.class)
public class SkyRenderingMixin {
    @ModifyVariable(method = "renderTopSky", at = @At("HEAD"), argsOnly = true)
    private int autismclient$darkSky(int color) {
        return Modules.DARK_SKY.enabled ? Modules.skyColor() : color;
    }

    @ModifyVariable(method = "renderCelestialBodies", at = @At("HEAD"), argsOnly = true, ordinal = 4)
    private float autismclient$stars(float starBrightness) {
        return Modules.ALWAYS_STARS.enabled ? 1.0f : starBrightness;
    }

    @Inject(method = "renderSun", at = @At("HEAD"), cancellable = true, require = 0)
    private void autismclient$noSun(CallbackInfo ci) {
        if (Modules.DARK_SKY.enabled) {
            ci.cancel();
        }
    }

    @Inject(method = "renderMoon", at = @At("HEAD"), cancellable = true, require = 0)
    private void autismclient$noMoon(CallbackInfo ci) {
        if (Modules.DARK_SKY.enabled) {
            ci.cancel();
        }
    }
}
